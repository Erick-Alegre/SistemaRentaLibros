package Classes;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Prestamo {
    private int IDBoleta;
    private int IDRecepcionista;
    private int IDCliente;
    private int IDLibro;

    public Prestamo(int IDBoleta, int IDRecepcionista, int IDCliente, int IDLibro) {
        this.IDBoleta = IDBoleta;
        this.IDRecepcionista = IDRecepcionista;
        this.IDCliente = IDCliente;
        this.IDLibro = IDLibro;
    }

    public int getIDBoleta() {
        return IDBoleta;
    }

    public void setIDBoleta(int IDBoleta) {
        this.IDBoleta = IDBoleta;
    }

    public int getIDRecepcionista() {
        return IDRecepcionista;
    }

    public void setIDRecepcionista(int IDRecepcionista) {
        this.IDRecepcionista = IDRecepcionista;
    }

    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int IDCliente) {
        this.IDCliente = IDCliente;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }
    
    public void anadirBoleta(List<Prestamo> boletas, int newIDBoleta, int newIDRecepcionista, int newIDCliente, int newIDLibro){
        Prestamo newTicket = new Prestamo(newIDBoleta, newIDRecepcionista, newIDCliente, newIDLibro);
        boletas.add(newTicket);
    }
    
    public void mostrarBoleta(List<Empleado> usuarios, List<Cliente> clientes, List<Libro> libros){
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DE LA BOLETA");
        System.out.println("ID de la boleta: " + this.IDBoleta);
        System.out.print("Nombre del recepcionista: ");
        for(Empleado user : usuarios){
            if(user.getID() == this.IDRecepcionista){
                System.out.println(user.getNombre());
            }
        }
        System.out.print("Nombre del cliente: ");
        for(Cliente client : clientes){
            if(client.getID() == this.IDCliente){
                System.out.println(client.getNombre());
            }
        }
        System.out.print("Nombre del libro: ");
        for(Libro book : libros){
            if(book.getID() == this.IDLibro){
                System.out.println(book.getTitulo());
            }
        }
    }
}

package Classes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Libro {
    private int ID;
    private String titulo;
    private String fechaPublicacion;
    private String editorial;
    private String genero;
    private int nPaginas;
    private int unidDisponibles;

    public Libro(int ID, String titulo, String fechaPublicacion, String editorial, String genero, int nPaginas, int unidDisponibles) {
        this.ID = ID;
        this.titulo = titulo;
        this.fechaPublicacion = fechaPublicacion;
        this.editorial = editorial;
        this.genero = genero;
        this.nPaginas = nPaginas;
        this.unidDisponibles = unidDisponibles;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(String fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getnPaginas() {
        return nPaginas;
    }

    public void setnPaginas(int nPaginas) {
        this.nPaginas = nPaginas;
    }

    public int getUnidDisponibles() {
        return unidDisponibles;
    }

    public void setUnidDisponibles(int unidDisponibles) {
        this.unidDisponibles = unidDisponibles;
    }
    
    //Otras funciones
    public void mostrarLibro(){
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DEL LIBRO " + this.titulo.toUpperCase());
        System.out.println("ID: " + this.ID);
        System.out.println("Título: " + this.titulo);
        System.out.println("Fecha de publicación: " + this.fechaPublicacion);
        System.out.println("Editorial: " + this.editorial);
        System.out.println("Género: " + this.genero);
        System.out.println("Nro de páginas: " + this.nPaginas);
        System.out.println("Unidades disponibles: " + this.unidDisponibles);
    }
    
    public boolean filtrarLibro(String tipoFiltro, String tipoData, String dataFiltro){//RECONSTRUIR
        boolean ver = false;
        if(tipoData.equals("fechaPublicacion")){//Verificar si una fecha es anterior o posterior a otra
            switch(tipoFiltro){
                case "Anterior":
                    //
                case "Igual":
                    ver = this.fechaPublicacion.equals(darFechaFormato(dataFiltro));
                case "Posterior":
                    //
            }
        }
        if(tipoData.equals("editorial")){
            ver = this.editorial.equals(dataFiltro);
        }
        if(tipoData.equals("genero")){
            ver = this.genero.equals(dataFiltro);
        }
        if(tipoData.equals("nPaginas")){
            switch(tipoFiltro){
                case "Mayor":
                    ver = (this.nPaginas > Integer.parseInt(dataFiltro));
                case "Igual":
                    ver = (this.nPaginas == Integer.parseInt(dataFiltro));
                case "Menor":
                    ver = (this.nPaginas > Integer.parseInt(dataFiltro));
            }
        }
        return ver;
    }
    
    private Date darFechaFormato(String fecha){
        SimpleDateFormat formato = new SimpleDateFormat("dd-mm-yyyy");
        Date newFecha = null;
        try {
            newFecha = formato.parse(fecha);
        } catch (ParseException ex) {
            Logger.getLogger(Libro.class.getName()).log(Level.SEVERE, null, ex);
        }
        return newFecha;
    }
}

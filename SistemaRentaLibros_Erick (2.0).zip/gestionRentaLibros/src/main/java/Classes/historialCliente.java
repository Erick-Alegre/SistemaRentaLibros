package Classes;

import com.mycompany.java.gestionrentalibros.FuncionesRecepcionista;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class historialCliente {
    private int IDCliente;
    private int IDLibro;
    private String fechaPrestamo;
    private String fechaEstimadaDevolucion;
    private String fechaRealDevolucion;

    public historialCliente(int IDCliente, int IDLibro, String fechaPrestamo, String fechaEstimadaDevolucion, String fechaRealDevolucion) {
        this.IDCliente = IDCliente;
        this.IDLibro = IDLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaEstimadaDevolucion = fechaEstimadaDevolucion;
        this.fechaRealDevolucion = fechaRealDevolucion;
    }

    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int IDCliente) {
        this.IDCliente = IDCliente;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }

    public String getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(String fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public String getFechaEstimadaDevolucion() {
        return fechaEstimadaDevolucion;
    }

    public void setFechaEstimadaDevolucion(String fechaEstimadaDevolucion) {
        this.fechaEstimadaDevolucion = fechaEstimadaDevolucion;
    }

    public String getFechaRealDevolucion() {
        return fechaRealDevolucion;
    }

    public void setFechaRealDevolucion(String fechaRealDevolucion) {
        this.fechaRealDevolucion = fechaRealDevolucion;
    }

    
    
    //
    
    public void anadirHistorialCliente(){
        
    }
    
    public void mostrarHistorialCliente(List<Cliente> clientes, List<Libro> libros, int idActualCliente){
        if(this.IDCliente == idActualCliente){
            System.out.print(this.IDLibro + "\t\t");
            for(Libro book : libros){
                if(book.getID() == this.IDLibro){
                    System.out.print(book.getTitulo() + "\t\t");
                }
            }
            System.out.print(this.fechaPrestamo + "\t\t");
            if(this.fechaRealDevolucion.equals("0")){
                System.out.println("PENDIENTE");
            }else{
                System.out.println(this.fechaRealDevolucion);
            }
        }
    }
}

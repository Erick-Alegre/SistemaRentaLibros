package com.mycompany.java.gestionrentalibros;

import Classes.Autor;
import static com.mycompany.java.gestionrentalibros.MainFunciones.*;
import static com.mycompany.java.gestionrentalibros.FuncionesLecturaCSV.*;
//import static com.mycompany.java.gestionrentalibros.FuncionesEscrituraCSV.*;
import static com.mycompany.java.gestionrentalibros.FuncionesAdministrador.*;
import static com.mycompany.java.gestionrentalibros.FuncionesRecepcionista.*;
import static com.mycompany.java.gestionrentalibros.FuncionesMostrarDatos.*;

import Classes.Prestamo;
import Classes.Libro;
import Classes.Empleado;
import Classes.Cliente;
import Classes.historialCliente;
import com.opencsv.*;
import com.opencsv.exceptions.CsvValidationException;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;

//Para hallar el filtro con varias cateegorías, se podría usar set para cada búsqueda y obtener los resultados de la intersección
//Max. de libros prestados: 6
//Las IDs de valor 0 indican que no hay valor
//NOTA: Las funciones de busqueda deben aceptar el ingreso de más valores para una mayor presición (Administrador)
//Añadir la función de "Confirmar devolución"
//La visualización de funciones

//ELIMINAR FUNCIONES DE MODIFICACION DE BASE DE DATOS

//En cada clase se implementarán funciones para modificar la base de datos
//El administrador debería poder modificar su información personal

public class GestionRentaLibros {
    
    static int option;
    static List<String> datosInicioSesion;
    static int IDActualUser;
    static boolean inicioSesionValido;
    static boolean band1 = true, band2 = true, band3 = true;
    static String[] fila;
    static CSVReader csvReader;
    
    public static void main(String[] args) {
        //Guardando la ruta del archivo CSV de usuarios, clientes, libros, boletas
        //Si no funciona, verificar la ubicación del archivo CSV
        //CAMBIAR POR LECTURA DE BASES DE DATOS MySQL
        String archCSVUser = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\empleados.csv";
        String archCSVClient = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\clientes.csv";
        String archCSVBook = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\libros.csv";
        String archCSVTicket = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\prestamos.csv";
        String archCSVAuthors = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\autores.csv";
        String archCSVClientRecord = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\historialClientes.csv";
        
        //ALMACENANDO LA BASE DE DATOS EN UNA LISTA DE OBJETOS DE SUS CLASES RESPECTIVAS
        //¿Como se trabajará con base de datos?
        List<Empleado> usuarios = LecturaBaseDatosUsuarios(archCSVUser);
        List<Cliente> clientes = LecturaBaseDatosClientes(archCSVClient);
        List<Libro> libros = LecturaBaseDatosLibros(archCSVBook);
        List<Prestamo> prestamos = LecturaBaseDatosBoletas(archCSVTicket);
        List<Autor> autores = LecturaBaseDatosAutores(archCSVAuthors);
        List<historialCliente> historialClientes = LecturaBaseDatosHistorialClientes(archCSVClientRecord);
        
        //PRUEBA DE USO DE BASE DE DATOS
        Statement stm;
        ResultSet rs;
        
        CConexion newConexion = new CConexion();
        newConexion.establecerConexion();
        
        //MENU PRINCIPAL
        do{
            option = mainMenu();
            switch(option){
                case 1:
                    //Gestion de recepcionista
                    datosInicioSesion = inicioSesion(usuarios);
                    for(Empleado user : usuarios){//Obtención del ID
                        if(datosInicioSesion.get(1).equals(user.getNombre()) && datosInicioSesion.get(2).equals(user.getContrasena())){
                            datosInicioSesion.add(Integer.toString(user.getID()));
                            break;
                        }
                    }
                    if("Administrador".equals(datosInicioSesion.get(0))){
                        //PARA EL ADMINISTRADOR
                        band1 = true;
                        do{
                            option = administradorMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    //GESTIÓN DE RECEPCIONISTAS
                                    band2 = true;
                                    do{
                                        recepcionistasVistaPrevia(usuarios);
                                        option = administradorGestionRecepcionistas();
                                        switch(option){
                                            case 1:
                                                //Ver detalles
                                                int selectRecepcionista = administradorSeleccionRecepcionista(usuarios); //selectRecepcionista: ID del recepcionista buscado
                                                recepcionistaVistaDetallada(usuarios, selectRecepcionista);
                                                option = administradorVerDetallesRecepcionista();
                                                switch(option){
                                                    case 1:
                                                        //Modificar nombre
                                                        administradorModificarNombreRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 2:
                                                        //Modificar DNI
                                                        administradorModificarDNIRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 3:
                                                        //Modificar posición
                                                        administradorModificarPosicionRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 4:
                                                        //Modificar contraseña
                                                        administradorModificarContrasenaRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 5:
                                                        //Modificar horario
                                                        administradorModificarHorarioRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 0:
                                                        band2 = true;
                                                }
                                                break;
                                            case 2:
                                                //Añadir
                                                administradorAnadirRecepcionista(usuarios);
                                                break;
                                            case 3:
                                                //Eliminar
                                                administradorEliminarRecepcionista(usuarios);
                                                break;
                                            case 4:
                                                //Buscar
                                                System.out.println("PENDIENTE");
                                                break;
                                            case 5:
                                                //Filtrar
                                                System.out.println("PENDIENTE");
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                        //actualizarBaseDatosUsuarios(archCSVUser, usuarios); //AUTOMATICO, SIN UTILIZAR
                                    }while(band2);
                                    break;
                                case 2:
                                    //GESTION DE CLIENTES
                                    band2 = true;
                                    do{
                                        clientesVistaPrevia(clientes);
                                        option = administradorGestionClientes();
                                        switch(option){
                                            case 1:
                                                //Buscar clientes
                                                band3 = true;
                                                do{
                                                    option = administradorBuscarClientes(clientes);
                                                    if(option == 0) band3 = false;
                                                }while(band3);
                                                break;
                                            case 2:
                                                //Filtrar clientes
                                                option = administradorMenuFiltrarClientes();
                                                switch(option){
                                                    case 1:
                                                        option = administradorSeleccionCriterioFiltro();
                                                        switch(option){
                                                            case 1:
                                                                //Menor
                                                                administradorFiltrarClientes(clientes, "Menor", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                            case 2:
                                                                //Igual
                                                                administradorFiltrarClientes(clientes, "Igual", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                            case 3:
                                                                //Mayor
                                                                administradorFiltrarClientes(clientes, "Mayor", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                        }
                                                        break;
                                                    case 2:
                                                        administradorFiltrarClientes(clientes, null, "estadoSancion", administradorIngresoDataFiltro("estadoSancion"));
                                                        break;
                                                    case 0:
                                                        //
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 3:
                                    //GESTIÓN DE LIBROS
                                    band2 = true;
                                    do{
                                        librosVistaPrevia(libros);
                                        option = recepcionistaConsultaLibros();
                                        switch(option){
                                            case 1:
                                                //Buscar
                                                band2 = true;
                                                do{
                                                    option = recepcionistaBuscarLibros(clientes, libros);
                                                    if(option == 0) band2 = false;
                                                }while(band2);
                                                break;
                                            case 2:
                                                //Filtrar
                                                option = recepcionistaMenuFiltrarLibros();
                                                switch(option){
                                                    case 1:
                                                        //FechaPublicacion
                                                        option = recepcionistaSeleccionCriterioFiltro("fechaPublicacion");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Anterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Posterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                            }
                                                        break;
                                                    case 2:
                                                        //Editorial
                                                        recepcionistaFiltrarLibros(libros, null, "editorial", recepcionistaIngresoDataFiltro("editorial"));
                                                        break;
                                                    case 3:
                                                        //Genero
                                                        recepcionistaFiltrarLibros(libros, null, "genero", recepcionistaIngresoDataFiltro("genero"));
                                                        break;
                                                    case 4:
                                                        //N Paginas
                                                        option = recepcionistaSeleccionCriterioFiltro("nPaginas");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Menor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Mayor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                            }
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 4:
                                    //CONSULTA DE INFORMACIÓN PERSONAL
                                    consultaInformacionPersonal(datosInicioSesion.get(3), usuarios);
                                    System.out.println("1.- Modificar información personal");
                                    System.out.println("0.- Volver");
                                    option = seleccionOpcion(0,1);
                                    if(option == 1){
                                        int selectEmpleado = Integer.parseInt(datosInicioSesion.get(3));
                                        option = administradorVerDetallesRecepcionista();
                                        switch(option){
                                            case 1:
                                                //Modificar nombre
                                                administradorModificarNombreRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 2:
                                                //Modificar DNI
                                                administradorModificarDNIRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 3:
                                                //Modificar contraseña
                                                administradorModificarContrasenaRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 4:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 5:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 0:
                                                band2 = true;
                                        }
                                    }
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                            }
                        }while(band1);
                    }else{
                        //PARA EL RECEPCIONISTA
                        band1 = true;
                        do{
                            option = recepcionistaMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    //Gestión de clientes
                                    band2 = true;
                                    do{
                                        clientesVistaPrevia(clientes);
                                        option = recepcionistaGestionClientes();
                                        switch(option){
                                            case 1:
                                                //Ver detalles de un cliente
                                                int idActualCliente;
                                                System.out.println("----------------------------------------");
                                                System.out.println("Ingrese el ID del cliente: ");
                                                idActualCliente = Integer.parseInt(read.nextLine());
                                                clienteVistaDetallada(clientes, idActualCliente);
                                                option = recepcionistaVerDetallesCliente(clientes);
                                                if(option == 1) recepcionistaMostrarHistorialCliente(clientes, historialClientes, libros, idActualCliente);
                                                break;
                                            case 2:
                                                //Añadir cliente
                                                recepcionistaAnadirCliente(clientes, historialClientes);
                                                break;
                                            case 3:
                                                //Eliminar cliente
                                                
                                                break;
                                            case 4:
                                                //Buscar clientes
                                                
                                                break;
                                            case 5:
                                                //Filtrar clientes
                                                
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 2:
                                    //Consulta de libros
                                    band2 = true;
                                    do{
                                        librosVistaPrevia(libros);
                                        option = recepcionistaConsultaLibros();
                                        switch(option){
                                            case 1:
                                                //Buscar
                                                band2 = true;
                                                do{
                                                    option = recepcionistaBuscarLibros(clientes, libros);
                                                    if(option == 0) band2 = false;
                                                }while(band2);
                                                break;
                                            case 2:
                                                //Filtrar
                                                option = recepcionistaMenuFiltrarLibros();
                                                switch(option){
                                                    case 1:
                                                        //FechaPublicacion
                                                        option = recepcionistaSeleccionCriterioFiltro("fechaPublicacion");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Anterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Posterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                            }
                                                        break;
                                                    case 2:
                                                        //Editorial
                                                        recepcionistaFiltrarLibros(libros, null, "editorial", recepcionistaIngresoDataFiltro("editorial"));
                                                        break;
                                                    case 3:
                                                        //Genero
                                                        recepcionistaFiltrarLibros(libros, null, "genero", recepcionistaIngresoDataFiltro("genero"));
                                                        break;
                                                    case 4:
                                                        //N Paginas
                                                        option = recepcionistaSeleccionCriterioFiltro("nPaginas");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Menor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Mayor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                            }
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 3:
                                    //Realizar préstamo
                                    band2 = true;
                                    boolean aux = false;
                                    do{
                                        String actualClient, actualBook;
                                        int IDCliente, IDLibro;
                                        System.out.print("Ingrese el nombre del cliente: ");
                                        actualClient = read.nextLine();
                                        //Verificar que el cliente esté en el sistema
                                        IDCliente = busquedaNombreCliente(clientes, actualClient);
                                        if(IDCliente == 0){
                                            System.out.println("El cliente no se encuentra registrado");
                                            System.out.println("1.- Iniciar nuevo préstamo");
                                            System.out.println("0.- Volver al menú principal");
                                            do{
                                                option = Integer.parseInt(read.nextLine());
                                                if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                            }while(option<0 || option >1);
                                            if(option == 0){
                                                break;
                                            }
                                        }else{
                                            //Verificar que el cliente no tenga deudas pendientes
                                            for(Cliente client : clientes){
                                                if(actualClient.equals(client.getNombre()) && client.getEstadoSancion()) aux = true;
                                            }
                                            if(aux){
                                                System.out.println("El cliente tiene libros pendientes de devolución");
                                                System.out.println("1.- Iniciar nuevo préstamo");
                                                System.out.println("0.- Volver al menú principal");
                                                do{
                                                    option = Integer.parseInt(read.nextLine());
                                                    if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                }while(option<0 || option >1);
                                                if(option == 0){
                                                    break;
                                                }
                                            }else{
                                                System.out.print("Ingrese el nombre del libro a prestar: ");
                                                actualBook = read.nextLine();
                                                //Verificar que el libro esté en el sistema
                                                IDLibro = busquedaNombreLibro(libros, actualBook);
                                                if(IDLibro == 0){
                                                    System.out.println("El libro no se encuentra registrado");
                                                    System.out.println("1.- Iniciar nuevo préstamo");
                                                    System.out.println("0.- Volver al menú principal");
                                                    do{
                                                        option = Integer.parseInt(read.nextLine());
                                                        if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                    }while(option<0 || option >1);
                                                    if(option == 0){
                                                        break;
                                                    }
                                                }else{
                                                    //Verificar si hay unidades disponibles del libro
                                                    aux = false;
                                                    for(Libro book : libros){
                                                        if(actualBook.equals(book.getTitulo()) && book.getUnidDisponibles()==0) aux = true;
                                                    }
                                                    if(aux){
                                                        System.out.println("No hay unidades disponible del libro");
                                                        System.out.println("1.- Iniciar nuevo préstamo");
                                                        System.out.println("0.- Volver al menú principal");
                                                        do{
                                                            option = Integer.parseInt(read.nextLine());
                                                            if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                        }while(option<0 || option >1);
                                                        if(option == 0){
                                                            break;
                                                        }
                                                    }else{
                                                        if(ConfirmarModificacion()){
                                                            //Se añade el préstamo
                                                            Prestamo newTicket = new Prestamo(generacionIDAleatorio(clientes, prestamos, "Prestamo"), Integer.parseInt(datosInicioSesion.get(3)), IDCliente, IDLibro);
                                                            prestamos.add(newTicket);
                                                            //Se añade al historial del cliente
                                                            
                                                            //Reducción de una unidad del libro
                                                            for(Libro book : libros){
                                                                if(book.getID() == IDLibro) book.setID(book.getID()-1);
                                                            }
                                                            System.out.println("El préstamo se realizó correctamente");
                                                        }else{
                                                            System.out.println("El préstamo no se ha realizado");
                                                        }
                                                        band2 = false;
                                                    }
                                                }
                                            }
                                        }
                                    }while(band2);
                                    break;
                                case 4:
                                    //Confirmar devolución
                                    band2 = true;
                                    do{
                                        String actualClient, actualBook;
                                        int IDCliente, IDLibro;
                                        System.out.print("Ingrese el nombre del cliente: ");
                                        actualClient = read.nextLine();
                                        IDCliente = busquedaNombreCliente(clientes, actualClient);
                                        //Verificar que el cliente esté en el sistema
                                        if(IDCliente == 0){
                                            System.out.println("El cliente no se encuentra registrado");
                                            System.out.println("1.- Iniciar nuevo proceso de devolución");
                                            System.out.println("0.- Volver al menú principal");
                                            do{
                                                option = Integer.parseInt(read.nextLine());
                                                if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                            }while(option<0 || option >1);
                                            if(option == 0) break;
                                        }else{
                                            //Se muestran los libros pendientes de devolucion
                                            aux = false;
                                            System.out.println("----------------------------------------");
                                            System.out.println("LIBROS PENDIENTES DE DEVOLUCIÓN: ");
                                            System.out.println("Libro\t\tFecha de Préstamo");
                                            for(historialCliente record : historialClientes){
                                                if(record.getIDCliente() == IDCliente && record.getFechaRealDevolucion().equals("0")){
                                                    System.out.println(busquedaIDLibro(libros, record.getIDLibro()) + "\t\t" + record.getFechaPrestamo());
                                                    aux = true;
                                                }
                                            }
                                            System.out.println("----------------------------------------");
                                            if(!aux){
                                                System.out.println("No se encontraron libros pendientes de devolución");
                                            }else{
                                                System.out.print("Ingrese el ID del libro que se va a devolver: ");
                                                IDLibro = Integer.parseInt(read.nextLine());
                                                //Verificar que el libro esté en el sistema
                                                actualBook = busquedaIDLibro(libros, IDLibro);
                                                if(actualBook.equals("")){
                                                    System.out.println("El libro no se encuentra registrado");
                                                    System.out.println("1.- Iniciar nuevo préstamo");
                                                    System.out.println("0.- Volver al menú principal");
                                                    do{
                                                        option = Integer.parseInt(read.nextLine());
                                                        if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                    }while(option<0 || option >1);
                                                    if(option == 0){
                                                        break;
                                                    }
                                                }else{
                                                    //Se confirma la devolucion
                                                    if(ConfirmarModificacion()){
                                                        //Se actualiza la fecha real de devolucion del libro
                                                        
                                                        //Aumento de una unidad del libro
                                                        for(Libro book : libros){
                                                            if(book.getID() == IDLibro) book.setID(book.getID()+1);
                                                        }
                                                        System.out.println("El préstamo se realizó correctamente");
                                                    }else{
                                                        System.out.println("El préstamo no se ha realizado");
                                                    }
                                                    band2 = false;
                                                }
                                            }
                                        }
                                        
                                    }while(band2);
                                    break;
                                case 5:
                                    //Ver información personal (Se puede incluir la consulta de boletas generadas)
                                    consultaInformacionPersonal(datosInicioSesion.get(3), usuarios);
                                    System.out.println("1.- Modificar información personal");
                                    System.out.println("2.- Ver préstamos generados");
                                    System.out.println("0.- Volver");
                                    option = seleccionOpcion(0,2);
                                    if(option == 1){
                                        int selectEmpleado = Integer.parseInt(datosInicioSesion.get(3));
                                        option = administradorVerDetallesRecepcionista();
                                        switch(option){
                                            case 1:
                                                //Modificar nombre
                                                administradorModificarNombreRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 2:
                                                //Modificar DNI
                                                administradorModificarDNIRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 3:
                                                //Modificar contraseña
                                                administradorModificarContrasenaRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 4:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 5:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 0:
                                                band2 = true;
                                        }
                                    }else if(option == 2){
                                        //Mostrar historial de préstamos generadas
                                        boletasVistaPrevia(prestamos, clientes, libros, usuarios, datosInicioSesion.get(0));
                                        System.out.println("1.- Ver detalles de boletas por ID");
                                        System.out.println("0.- Volver");
                                        option = seleccionOpcion(0,1);
                                        switch(option){
                                            case 1:
                                                band2 = true;
                                                do{
                                                    System.out.print("Ingrese la ID de la boleta: ");
                                                    band2 = boletaVistaDetallada(prestamos, usuarios, clientes, libros, datosInicioSesion.get(1), read.nextInt());
                                                }while(band2);
                                                break;
                                            case 0:

                                                break;
                                        }
                                    }
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                                    break;
                            }
                        }while(band1);
                    }
                    break;
                case 0:
                    inicioSesionValido = false;
                    break;
            }
        }while(inicioSesionValido);
        
        System.out.println("ALL WORKING");
    }
}

package com.mycompany.java.gestionrentalibros;

import Classes.Autor;
import Classes.Prestamo;
import Classes.Cliente;
import Classes.Libro;
import Classes.Empleado;
import Classes.historialCliente;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.csvReader;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.fila;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class FuncionesLecturaCSV {
    //FUNCIONES DE LECTURA DE CSV
    //Usuarios
    static List<Empleado> LecturaBaseDatosUsuarios(String CSVLocation){
        List<Empleado> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    Empleado data = new Empleado(Integer.parseInt(fila[0]),fila[1],Integer.parseInt(fila[2]),fila[3],fila[4],Integer.parseInt(fila[5]),Integer.parseInt(fila[6]));
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
    
    //Clientes
    static List<Cliente> LecturaBaseDatosClientes(String CSVLocation){
        List<Cliente> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    Cliente data = new Cliente(Integer.parseInt(fila[0]), fila[1], Integer.parseInt(fila[2]), Integer.parseInt(fila[3]), Integer.parseInt(fila[4]), fila[5]);
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
    
    //Libros
    static List<Libro> LecturaBaseDatosLibros(String CSVLocation){
        List<Libro> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    Libro data = new Libro(Integer.parseInt(fila[0]), fila[1], fila[2], fila[3], fila[4], Integer.parseInt(fila[5]), Integer.parseInt(fila[6]));
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
    
    //Boletas de rentas
    static List<Prestamo> LecturaBaseDatosBoletas(String CSVLocation){
        List<Prestamo> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    Prestamo data = new Prestamo(Integer.parseInt(fila[0]), Integer.parseInt(fila[1]), Integer.parseInt(fila[2]), Integer.parseInt(fila[3]));
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
    
    //Autores
    static List<Autor> LecturaBaseDatosAutores(String CSVLocation){
        List<Autor> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    Autor data = new Autor(fila[0], Integer.parseInt(fila[1]));
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
    
    //Historial de cliente
    static List<historialCliente> LecturaBaseDatosHistorialClientes(String CSVLocation){
        List<historialCliente> allData = new ArrayList<>();
        boolean auxiliar = false; //Evita la lectura de la primera línea (columnas)
        try {
            csvReader = new CSVReader(new FileReader(CSVLocation));
            fila = null;
            while ((fila = csvReader.readNext()) != null) {
                if(auxiliar){
                    historialCliente data = new historialCliente(Integer.parseInt(fila[0]), Integer.parseInt(fila[1]), fila[2], fila[3], fila[4]);
                    allData.add(data);
                }
                auxiliar = true;
            }
            csvReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allData;
    }
}

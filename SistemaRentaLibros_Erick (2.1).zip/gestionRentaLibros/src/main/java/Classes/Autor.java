package Classes;

public class Autor {
    String nombreAutor;
    int IDLibro;

    public Autor(String nombreAutor, int IDLibro) {
        this.nombreAutor = nombreAutor;
        this.IDLibro = IDLibro;
    }

    public String getNombreAutor() {
        return nombreAutor;
    }

    public void setNombreAutor(String nombreAutor) {
        this.nombreAutor = nombreAutor;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }
    
    
}

package Classes;

import com.mycompany.java.gestionrentalibros.CConexion;
import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {
    private int ID;
    private String Nombre;
    private int DNI;
    private int Telefono;
    private int cantLibrosPrestados;
    private boolean estadoSancion;

    public Cliente(int ID, String Nombre, int DNI, int Telefono, int cantLibrosPrestados, String estadoSancion) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.DNI = DNI;
        this.Telefono = Telefono;
        this.cantLibrosPrestados = cantLibrosPrestados;
        if(estadoSancion.equals("Si")) this.estadoSancion = true;
        else this.estadoSancion = false;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public int getCantLibrosPrestados() {
        return cantLibrosPrestados;
    }

    public void setCantLibrosPrestados(int cantLibrosPrestados) {
        this.cantLibrosPrestados = cantLibrosPrestados;
    }
    
    public boolean getEstadoSancion() {
        return estadoSancion;
    }

    public void setEstadoSancion(boolean estadoSancion) {
        this.estadoSancion = estadoSancion;
    }
    
    //Otros métodos o funciones
    //MySQL
    public void anadirCliente(){
        
        CConexion newConexion = new CConexion();
        
        String consulta = "insert into clientes (nombre, DNI, telefono, cantLibrosPrestados, estadoSancion) values (" + this.Nombre + ", " + this.DNI + ", " + this.Telefono + ", " + this.cantLibrosPrestados + ", " + this.estadoSancion + ");";
        
        try {
            CallableStatement cs = newConexion.establecerConexion().prepareCall(consulta);
            cs.execute();
            System.out.println("El cliente se insertó correctamente");
        } catch (SQLException ex) {
            System.out.println("Error al insertar al cliente");
        }
    }
    
    public void mostrarCliente(){
        String eSancion;
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DEL CLIENTE");
        System.out.println("ID: " + this.ID);
        System.out.println("Nombre: " + this.Nombre);
        System.out.println("DNI: " + this.DNI);
        System.out.println("Teléfono: " + this.Telefono);
        System.out.println("Cantidad de libros en préstamo: " + this.cantLibrosPrestados);
        eSancion = (this.estadoSancion==true)?"ACTIVO":"INACTIVO";
        System.out.println("Estado de sanción: " + eSancion);
    }
    
    public void eliminarCliente(List<Cliente> clientes, Cliente client){
        clientes.remove(client);
    }
    
    public boolean filtrarCliente(String tipoFiltro, String tipoData, String dataFiltro){ //tipoFiltro: Mayor, igual o menor //tipoData: numLibros o estadoSancion //dataFiltro: El dato para filtrar
        boolean ver = true;
        if(tipoData.equals("cantLibrosPrestados")){
            switch(tipoFiltro){
                case "Menor":
                    ver = this.cantLibrosPrestados < Integer.parseInt(dataFiltro);
                case "Igual":
                    ver = this.cantLibrosPrestados == Integer.parseInt(dataFiltro);
                case "Mayor":
                    ver = this.cantLibrosPrestados > Integer.parseInt(dataFiltro);
            }
        }
        if(tipoData.equals("estadoSancion")){
            if(dataFiltro.equals("ACTIVO")){
                ver = (this.estadoSancion == true);
            }else{
                ver = (this.estadoSancion == false);
            }
        }
        return ver;
    }
    
    public void anadirCliente(List<Cliente> clientes, int newID, String newNombre, int newDNI, int newTelefono){
        Cliente newClient = new Cliente(newID, newNombre, newDNI, newTelefono, 0, "No");
        clientes.add(newClient); 
    }
    
    public void eliminarCliente(){
        
    }
}
package com.mycompany.java.gestionrentalibros;

import Classes.Autor;
import Classes.Prestamo;
import Classes.Cliente;
import Classes.Libro;
import Classes.Empleado;
import Classes.historialCliente;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MainFunciones {
    
    static Scanner read = new Scanner(System.in);
    
    //Seleccion de opciones
    
    static int seleccionOpcion(int limiteInferior, int limiteSuperior){
        int opcion;
        do{
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(read.nextLine());
            if(opcion<limiteInferior || opcion >limiteSuperior) System.out.println("Opción inválida, intente nuevamente...");
        }while(opcion<limiteInferior || opcion >limiteSuperior);
        return opcion;
    }
    
    //Obtencion de fecha actual y otras fechas
    
    static String obtenerFechaActual(){
        Date fechaActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
        String fechaFormateada = formato.format(fechaActual);
        return fechaFormateada;
    }
    
    static String obtenerFechaDevolucion(String actualDate){
        String[] newDate = actualDate.split("-");
        return sumarDiasFecha(Integer.parseInt(newDate[0]), Integer.parseInt(newDate[1]), Integer.parseInt(newDate[2]));
    }
    
    static String sumarDiasFecha(int day, int month, int year){
        String newFechaDevolucion = "";
        if(month == 2){
            if(year%4==0 && year%400!=0){
                if(day>=15){
                    month = month + 1;
                    day = day - 14;
                }else{
                    day = day + 14;
                }
            }else{
                if(day>=14){
                    day = day - 14;
                }else{
                    day = day + 14;
                }
            }
        }else if(month == 4 || month == 6 || month == 9 || month == 11){
            if(day>=17){
                month = month + 1;
                day = day - 14;
            }
            else{
                day = day + 14;
            }
        }else{
            if(day>=18){
                if(month == 12){
                    month = 1;
                    year = year + 1;
                }else{
                    month = month + 1;
                }
                day = day - 14;
            }
            else{
                day = day + 14;
            }
        }
        newFechaDevolucion = day + "-" + month + "-" + year;
        return newFechaDevolucion;
    }
    
    static boolean compararFechas(List<historialCliente> historialClientes, int IDCliente, String cmpFecha1, String cmpFecha2){//Retorna 0 si la fecha1 es mayor, sino retorna 1
        String[] newFecha1 = cmpFecha1.split("-"), newFecha2 = cmpFecha2.split("-");
        if(Integer.parseInt(newFecha1[2]) != Integer.parseInt(newFecha2[2])){
            
        }else{
            if(Integer.parseInt(newFecha1[1]) != Integer.parseInt(newFecha2[1])){
                
            }else{
                if(Integer.parseInt(newFecha1[0]) != Integer.parseInt(newFecha2[0])){
                    
                }else{
                    
                }
            }
        }
        return true;
    }
    
    //Generar numero aleatorio (SOLO PARA CSV, NO SE USA EN BASE DE DATOS)
    
    static int generacionIDAleatorioCliente(List<Cliente> clientes, String criterio){
        int newID = 0;
        boolean unique;
        do{
            unique = true;
            newID = 1000 + (int)(Math.random()*9000);
            for(Cliente client : clientes){
                if(client.getID() == newID) unique = false;
            }
        }while(!unique);
        return newID;
    }
    
    static int generacionIDAleatorioPrestamo(List<Prestamo> prestamos, String criterio){
        int newID = 0;
        boolean unique;
        do{
            unique = true;
            newID = 1000000 + (int)(Math.random()*9000000);
            for(Prestamo lending : prestamos){
                if(lending.getIDBoleta() == newID) unique = false;
            }
        }while(!unique);
        return newID;
    }
    
    static int generacionIDAleatorioLibro(List<Libro> libros, String criterio){
        int newID = 0;
        boolean unique;
        do{
            unique = true;
            newID = 10000 + (int)(Math.random()*90000);
            for(Libro book : libros){
                if(book.getID() == newID) unique = false;
            }
        }while(!unique);
        return newID;
    }
    
    //MENU PRINCIPAL
    static int mainMenu(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO AL SISTEMA DE GESTIÓN DE RENTA DE LIBROS");
        System.out.println("1.- Iniciar sesión");
        System.out.println("0.- Salir");
        return seleccionOpcion(0, 1);
    }
    
    //FUNCION DE INICIO DE SESIÓN
    static List<String> inicioSesion(List<Empleado> usuarios){
        System.out.println("----------------------------------------");
        System.out.println("GESTIÓN DE RENTA DE LIBROS");
        System.out.println("----------------------------------------");
        List<String> datos = new ArrayList<>(3);
        String indDato;
        int opcion;
        System.out.println("INICIO DE SESIÓN");
        do{
            System.out.println("Ingrese su posición, usuario y contraseña");
            System.out.println("Posición:");
            System.out.println("1.- Administrador");
            System.out.println("2.- Recepcionista");
            opcion = seleccionOpcion(1,2);
            if(opcion ==1) datos.add("Administrador");
            else datos.add("Recepcionista");
            System.out.print("Usuario: ");
            indDato = read.nextLine();
            datos.add(indDato);
            System.out.print("Contraseña: ");
            indDato = read.nextLine();
            datos.add(indDato);

            //Verificando inicio de sesión
            inicioSesionValido = false;
            if("Administrador".equals(datos.get(0))){
                //Verificación con los objetos de la clase Usuario
                for(Empleado user : usuarios){
                    if(user.getPosicion().equals("Administrador") && (user.getNombre().equals(datos.get(1)) && user.getContrasena().equals(datos.get(2)))) inicioSesionValido = true;
                }
            }
            if("Recepcionista".equals(datos.get(0))){
                //Verificación con los objetos de la clase Usuario
                for(Empleado user : usuarios){
                    if(user.getPosicion().equals("Recepcionista") && (user.getNombre().equals(datos.get(1)) && user.getContrasena().equals(datos.get(2)))) inicioSesionValido = true;
                }
            }
            if(!inicioSesionValido){
                System.out.println("Inicio de sesion invalido, intente nuevamente...");
                datos.clear();
            }
        }while(!inicioSesionValido);
        System.out.println("Inicio de sesión realizado con éxito");
        for(Empleado user : usuarios){//Obtención del ID
            if(datos.get(1).equals(user.getNombre()) && datos.get(2).equals(user.getContrasena())){
                datos.add(Integer.toString(user.getID()));
                break;
            }
        }
        return datos;
    }
    
    //Funcion de obtención de nombre
    
    static String busquedaIDCliente(List<Cliente> clientes, int actualID){
        String nombre = "";
        boolean validarID = false;
        do{
            for(Cliente client : clientes){
                if(client.getID() ==actualID){
                    nombre = client.getNombre();
                    validarID = true;
                    break;
                }
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return nombre;
    }
    
    static String busquedaIDLibro(List<Libro> libros, int actualID){
        String nombre = "";
        boolean validarID = false;
        do{
            for(Libro book : libros){
                if(book.getID() ==actualID){
                    nombre = book.getTitulo();
                    validarID = true;
                    break;
                }
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return nombre;
    }
    
    static int busquedaID(List<Cliente> clientes, List<Empleado> usuarios, List<Libro> libros, List<Prestamo> boletas, List<Autor> autores, String criterioBusqueda, boolean mostrarTexto){
        int ID = 0;
        boolean validarID = false;
        do{
            switch(criterioBusqueda){
                case "Empleado":
                    for(Empleado user : usuarios){
                        if(user.getID() == ID){
                            validarID = true;
                            break;
                        }
                    }
                    break;
                case "Cliente":
                    for(Cliente client : clientes){
                        if(client.getID() == ID){
                            validarID = true;
                            break;
                        }
                    }
                    break;
                case "Libro":
                    for(Libro book : libros){
                        if(book.getID() == ID){
                            validarID = true;
                            break;
                        }
                    }
                    break;
                case "Préstamo":
                    for(Prestamo ticket : boletas){
                        if(ticket.getIDBoleta() == ID){
                            validarID = true;
                            break;
                        }
                    }
                    break;
                case "Autor":
                    for (Autor author : autores){
                        
                    }
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return ID;
    }
    
    //Funciones de obtencion de ID
    static int busquedaNombreEmpleado(List<Empleado> usuarios, String actualNombre){
        int ID = 0;
        for(Empleado user : usuarios){
            if(user.getNombre().equals(actualNombre)){
                ID = user.getID();
                break;
            }
        }
        return ID;
    }
    
    static int busquedaNombreCliente(List<Cliente> clientes, String actualNombre){
        int ID = 0;
        for(Cliente client : clientes){
            if(client.getNombre().equals(actualNombre)){
                ID = client.getID();
                break;
            }
        }
        return ID;
    }
    
    static int busquedaNombreLibro(List<Libro> libros, String actualNombre){
        int ID = 0;
        for(Libro book : libros){
            if(book.getTitulo().equals(actualNombre)){
                ID = book.getID();
                break;
            }
        }
        return ID;
    }
    
    //FUNCION DE CIERRE DE SESION
    static void cierreSesion(){
        System.out.println("----------------------------------------");
        System.out.println("SESION FINALIZADA");
        System.out.println("----------------------------------------");
    }
    
    static boolean ConfirmarModificacion(){
        boolean confirmacion;
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("¿Desea guardar los cambios realizados?");
        System.out.println("1.- SI");
        System.out.println("0.- NO");
        opcion = seleccionOpcion(0,1);
        confirmacion = (opcion == 1);
        return confirmacion;
    }
}

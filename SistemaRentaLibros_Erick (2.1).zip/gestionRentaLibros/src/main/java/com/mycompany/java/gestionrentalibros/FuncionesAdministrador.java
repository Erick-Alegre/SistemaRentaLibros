package com.mycompany.java.gestionrentalibros;

import Classes.*;
import static com.mycompany.java.gestionrentalibros.FuncionesMostrarDatos.*;
import static com.mycompany.java.gestionrentalibros.MainFunciones.*;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.*;

import java.util.List;

public class FuncionesAdministrador {
    //FUNCIONES DE ELECCION DE OPCIONES DE MENUS o DE INGRESO DE DATOS
    //ADMINISTRADOR
    static int administradorMainMenu(String nombre){
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO " + nombre.toUpperCase());
        System.out.println("1.- Gestión de recepcionistas");
        System.out.println("2.- Gestión de clientes"); //Dentro la gestión de su cuenta
        System.out.println("3.- Gestión de libros");
        System.out.println("4.- Consulta de información personal");
        System.out.println("0.- Cerrar sesión");
        return seleccionOpcion(0, 4);
    }
    
    static int administradorGestionRecepcionistas(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Ver detalles de un recepcionista"); //Dentro estaría "modificar datos del recepcionista"
        System.out.println("2.- Añadir recepcionista");
        System.out.println("3.- Eliminar recepcionista");
        System.out.println("4.- Buscar recepcionista");
        System.out.println("5.- Filtrar recepcionista");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 5);
    }
    
    static int administradorSeleccionRecepcionista(List<Empleado> usuarios){
        int recepcionistaID;
        boolean validarID = false;
        System.out.println("----------------------------------------");
        do{
            System.out.print("Ingrese el ID del recepcionista: ");
            recepcionistaID = Integer.parseInt(read.nextLine());
            for(Empleado user : usuarios){
                if(user.getID() == recepcionistaID) validarID = true;
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return recepcionistaID;
    }
    
    static int administradorVerDetallesRecepcionista(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Modificar nombre");
        System.out.println("2.- Modificar DNI");
        System.out.println("3.- Modificar posicion"); //En caso de ascenso
        System.out.println("4.- Modificar contraseña");
        System.out.println("5.- Modificar horario");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 5);
    }
    
    static void administradorModificarNombreRecepcionista(int IDRecepcionista, List<Empleado> usuarios){
        String newNombre;
        System.out.println("----------------------------------------");
        for(Empleado user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Nombre actual: " + user.getNombre());
                System.out.print("Ingrese el nuevo nombre: ");
                newNombre = read.nextLine();
                if(administradorConfirmarModificacion()){
                    user.setNombre(newNombre); //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarDNIRecepcionista(int IDRecepcionista, List<Empleado> usuarios){
        int newDNI;
        System.out.println("----------------------------------------");
        for(Empleado user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("DNI actual: " + user.getDNI());
                System.out.print("Ingrese el nuevo DNI: ");
                newDNI = Integer.parseInt(read.nextLine());
                if(administradorConfirmarModificacion()){
                    user.setDNI(newDNI); //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarPosicionRecepcionista(int IDRecepcionista, List<Empleado> usuarios){
        int opcion;
        System.out.println("----------------------------------------");
        for(Empleado user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Posicion actual: " + user.getPosicion());
                System.out.println("¿Desea cambiar su posición a administrador?");
                System.out.println("1.- SI");
                System.out.println("0.- NO");
                opcion = seleccionOpcion(0,1);
                if(opcion == 1){
                    user.setPosicion("Administrador");
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarContrasenaRecepcionista(int IDRecepcionista, List<Empleado> usuarios){
        String newContrasena;
        System.out.println("----------------------------------------");
        for(Empleado user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Contraseña actual: " + user.getNombre());
                System.out.print("Ingrese la nueva contraseña: ");
                newContrasena = read.nextLine();
                if(administradorConfirmarModificacion()){
                    user.setContrasena(newContrasena);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarHorarioRecepcionista(int IDRecepcionista, List<Empleado> usuarios){
        int newHoraInicio, newHoraFin;
        System.out.println("----------------------------------------");
        for(Empleado user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Horario actual: " + user.mostrarHorarioFormato(user.getHoraInicio(), user.getHoraFin()));
                System.out.print("Ingrese la nueva hora de inicio del turno (Formato 24h): ");
                do{
                    newHoraInicio = Integer.parseInt(read.nextLine());
                    if(newHoraInicio<1 || newHoraInicio >24) System.out.println("Opción inválida, intente nuevamente...");
                }while(newHoraInicio<1 || newHoraInicio >24);
                System.out.print("Ingrese la nueva hora de fin del turno (Formato 24h): ");
                do{
                    newHoraFin = Integer.parseInt(read.nextLine());
                    if(newHoraFin<1 || newHoraFin >24) System.out.println("Opción inválida, intente nuevamente...");
                    if(newHoraFin<newHoraInicio) System.out.println("La hora de fin ingresada es menor que la hora de inicio, intente nuevamente...");
                }while(newHoraFin<1 || newHoraFin >24 || newHoraFin<newHoraInicio);
                if(administradorConfirmarModificacion()){
                    user.setHoraInicio(newHoraInicio);
                    user.setHoraFin(newHoraFin);
                    //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorAnadirRecepcionista(List<Empleado> usuarios){
        String newNombre, newContrasena;
        int newID = 0, newDNI, newHoraInicio, newHoraFin;
        //Ingreso de datos
        System.out.println("----------------------------------------");
        System.out.println("AÑADIR NUEVO RECEPCIONISTA");
        System.out.print("Ingrese el nombre: ");
        newNombre = read.nextLine();
        System.out.print("Ingrese el DNI: ");
        newDNI = Integer.parseInt(read.nextLine());
        System.out.print("Ingrese la contraseña: ");
        newContrasena = read.nextLine();
        System.out.print("Ingrese la hora de inicio del turno: ");
        newHoraInicio = Integer.parseInt(read.nextLine());
        System.out.print("Ingrese la hora de final del turno: ");
        newHoraFin = Integer.parseInt(read.nextLine());
        if(administradorConfirmarModificacion()){
            //Generacion aleatoria de ID
            boolean unique;
            do{
                unique = true;
                newID = 100 + (int)(Math.random()*900);
                for(Empleado user : usuarios){
                    if(user.getID() == newID){
                        unique = false;
                    }
                }
            }while(!unique);
            usuarios.get(usuarios.size()-1).anadirUsuario(usuarios, newID, newNombre, newDNI, "Recepcionista", newContrasena, newHoraInicio, newHoraFin);
            System.out.println("Los cambios se han guardado correctamente");
        }else{
            System.out.println("Los cambios no han sido guardados");
        }
    }
    
    static List<Empleado> administradorEliminarRecepcionista(List<Empleado> usuarios){
        int selectID;
        boolean ver = false;
        System.out.println("----------------------------------------");
        System.out.println("ELIMINAR UN RECEPCIONISTA");
        do{
            System.out.print("Ingrese la ID del recepcionista a eliminar: ");
            selectID = Integer.parseInt(read.nextLine());
            for(Empleado user : usuarios){
                if(user.getPosicion().equals("Recepcionista") && user.getID() == selectID){
                    ver = true;
                    if(administradorConfirmarModificacion()){
                        user.eliminarUsuario(usuarios, user);
                        System.out.println("El usuario se ha eliminado correctamente");
                        break;
                    }else{
                        System.out.println("El usuario no ha sido eliminado");
                    }
                    break;
                }
            }
            if(!ver) System.out.println("ID no encontrada, intente nuevamente...");
        }while(!ver);
        return usuarios;
    }
    
    static boolean administradorConfirmarModificacion(){
        boolean confirmacion;
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("¿Desea guardar los cambios realizados?");
        System.out.println("1.- SI");
        System.out.println("0.- NO");
        opcion = seleccionOpcion(0,1);
        confirmacion = (opcion == 1);
        return confirmacion;
    }
    
    static int administradorGestionClientes(){
        System.out.println("----------------------------------------");
        System.out.println("1.- Ver detalles de un cliente"); //Modificar datos del cliente
        System.out.println("2.- Añadir cliente");
        System.out.println("3.- Eliminar cliente");
        System.out.println("4.- Buscar cliente");//Por nombre, por DNI, por telefono
        System.out.println("5.- Filtrar clientes"); //Por estado sanción, cantLibrosPrestados, 
        System.out.println("0.- Volver");
        return seleccionOpcion(0,5);
    }
    
    static List<Cliente> administradorEliminarCliente(List<Cliente> clientes){
        int selectID;
        boolean ver = false;
        System.out.println("----------------------------------------");
        System.out.println("ELIMINAR UN CLIENTE");
        do{
            System.out.print("Ingrese la ID del cliente a eliminar: ");
            selectID = Integer.parseInt(read.nextLine());
            for(Cliente client : clientes){
                if(client.getID() == selectID){
                    ver = true;
                    if(administradorConfirmarModificacion()){
                        client.eliminarCliente(clientes, client);
                        System.out.println("El cliente se ha eliminado correctamente");
                        break;
                    }else{
                        System.out.println("El cliente no ha sido eliminado");
                    }
                    break;
                }
            }
            if(!ver) System.out.println("ID no encontrada, intente nuevamente...");
        }while(!ver);
        return clientes;
    }
    
    static int administradorBuscarClientes(List<Cliente> clientes){
        String searchNombre;
        int searchDNI, searchTelefono;
        System.out.println("Ingrese la información del cliente (Caso contrario ingrese '0')");
        System.out.print("Ingrese el nombre del cliente: ");
        searchNombre = read.nextLine();
        System.out.print("Ingrese el DNI del cliente: ");
        searchDNI = Integer.parseInt(read.nextLine());
        System.out.print("Ingrese el teléfono del cliente: ");
        searchTelefono = Integer.parseInt(read.nextLine());
        System.out.println("----------------------------------------");
        System.out.println("CLIENTES ENCONTRADOS: ");
        for(Cliente client : clientes){
            boolean foundClient = true;
            if(!searchNombre.equals("0") && !client.getNombre().equals(searchNombre)) foundClient = false;
            if(searchDNI != 0 && client.getDNI() != searchDNI) foundClient = false;
            if(searchTelefono != 0 && client.getTelefono() != searchTelefono) foundClient = false;
            if(foundClient){
                clienteVistaDetallada(clientes, client.getID());
                System.out.print("Presione ENTER par continuar");
                read.nextLine();
            }
        }
        System.out.println("1.- Realizar otra búsqueda");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,1);
    }
    
    static int administradorMenuFiltrarClientes(){
        System.out.println("1.- Filtrar por cantidad de libros prestados");
        System.out.println("2.- Filtrar por estado de sanción");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,2);
    }
    
    
    static String administradorIngresoDataFiltro(String tipoData){
        if(tipoData.equals("cantLibrosPrestados")){
            System.out.print("Ingrese la cantidad: ");
        }else{
            System.out.print("Ingrese el estado de sanción (ACTIVO/INACTIVO): ");
        }
        return read.nextLine();
    }
    
    static void administradorFiltrarClientes(List<Cliente> clientes, String tipoFiltro, String tipoData, String dataFiltro){
        boolean ver = false;
        for(Cliente client : clientes){
            if(client.filtrarCliente(tipoFiltro, tipoData, dataFiltro)){
                ver = true;
                client.mostrarCliente(); //Posible cambio a vista previa
            }
        }
        if(!ver) System.out.println("No se encontraron datos con las indicaciones ingresadas");
        System.out.print("Presione ENTER para continuar ");//Revisar esto
        read.nextLine();
    }
    
    static void administradorModificarNombreLibro(int IDLibro, List<Libro> libros){
        String newNombre;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("Titulo actual: " + book .getTitulo());
                System.out.print("Ingrese el nuevo titulo: ");
                newNombre = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newNombre);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarFechaLibro(int IDLibro, List<Libro> libros){
        String newFecha;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("Fecha de publicación actual: " + book .getTitulo());
                System.out.print("Ingrese la nueva fecha de publicación (dd-mm-yyyy): ");
                newFecha = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newFecha);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarEditorialLibro(int IDLibro, List<Libro> libros){
        String newData;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("Editorial actual: " + book .getTitulo());
                System.out.print("Ingrese la nueva editorial: ");
                newData = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newData);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarGeneroLibro(int IDLibro, List<Libro> libros){ //Añadir verificación
        String newData;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("Genero actual: " + book .getTitulo());
                System.out.print("Ingrese el nuevo género: ");
                newData = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newData);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarNPaginasLibro(int IDLibro, List<Libro> libros){
        String newData;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("No de paginas actual: " + book .getTitulo());
                System.out.print("Ingrese el nuevo número de páginas: ");
                newData = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newData);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarUnidDisponiblesLibro(int IDLibro, List<Libro> libros){
        String newData;
        System.out.println("----------------------------------------");
        for(Libro book : libros){
            if(book.getID() == IDLibro){
                System.out.println("No de unidades disponibles actual: " + book .getTitulo());
                System.out.print("Ingrese el nuevo No de unidades disponibles: ");
                newData = read.nextLine();
                if(administradorConfirmarModificacion()){
                    book.setTitulo(newData);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorAnadirLibro(List<Libro> libros){
        String newTitulo, newFechaPublicacion, newEditorial, newGenero;
        int newNroPaginas, newUnidDisponibles;
        //Ingreso de datos
        System.out.println("----------------------------------------");
        System.out.println("AÑADIR NUEVO LIBRO");
        System.out.print("Ingrese el título: ");
        newTitulo = read.nextLine();
        System.out.print("Ingrese la fecha de publicación: ");
        newFechaPublicacion = read.nextLine();
        System.out.print("Ingrese la editorial: ");
        newEditorial = read.nextLine();
        System.out.print("Ingrese el género: ");
        newGenero = read.nextLine();
        System.out.print("Ingrese el número de páginas: ");
        newNroPaginas = Integer.parseInt(read.nextLine());
        System.out.println("Ingrese las unidades a agregar del libro: ");
        newUnidDisponibles = Integer.parseInt(read.nextLine());
        if(administradorConfirmarModificacion()){
            libros.get(libros.size()-1).anadirLibro(libros, generacionIDAleatorioLibro(libros, "Libro"), newTitulo, newFechaPublicacion, newEditorial, newGenero, newNroPaginas, newUnidDisponibles);
            System.out.println("Los cambios se han guardado correctamente");
        }else{
            System.out.println("Los cambios no han sido guardados");
        }
    }
    
    static List<Libro> administradorEliminarLibro(List<Libro> libros){
        int selectID;
        boolean ver = false;
        System.out.println("----------------------------------------");
        System.out.println("ELIMINAR UN LIBRO");
        do{
            System.out.print("Ingrese la ID del libro a eliminar: ");
            selectID = Integer.parseInt(read.nextLine());
            for(Libro book : libros){
                if(book.getID() == selectID){
                    ver = true;
                    if(administradorConfirmarModificacion()){
                        book.eliminarLibro(libros, book);
                        System.out.println("El usuario se ha eliminado correctamente");
                        break;
                    }else{
                        System.out.println("El usuario no ha sido eliminado");
                    }
                    break;
                }
            }
            if(!ver) System.out.println("ID no encontrada, intente nuevamente...");
        }while(!ver);
        return libros;
    }
}

package com.mycompany.java.gestionrentalibros;

import Classes.Prestamo;
import Classes.Cliente;
import Classes.Libro;
import Classes.Empleado;
import static com.mycompany.java.gestionrentalibros.MainFunciones.read;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.IDActualUser;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.datosInicioSesion;
import java.util.List;

public class FuncionesMostrarDatos {
    //FUNCIONES DE VISUALIZACION PREVIA DE DATOS
    static void recepcionistasVistaPrevia(List<Empleado> usuarios){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE RECEPCIONISTAS: ");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("ID\t\t\tNombre\t\t\tInicio Turno(h)\t\t\tFin Turno(h)");
        System.out.println("--------------------------------------------------------------------------------");
        for(Empleado user : usuarios){
            if(user.getPosicion().equals("Recepcionista")){
                System.out.println(user.getID() + "\t\t\t" + user.getNombre() + "\t\t\t" + user.getHoraInicio() + "\t\t\t" + user.getHoraFin());
            }
        }
    }
    
    static void clientesVistaPrevia(List<Cliente> clientes){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE CLIENTES: ");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("ID\t\tNombre\t\tN° Libros Prestados\tEstado de sanción");
        System.out.println("----------------------------------------------------------------------");
        for(Cliente client : clientes){
            System.out.println(client.getID() + "\t\t" + client.getNombre() + "\t\t" + client.getCantLibrosPrestados() + "\t\t\t" + client.getEstadoSancion());
        }
    }
    
    static void librosVistaPrevia(List<Libro> libros){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE LIBROS: ");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        System.out.println("ID\t\tTítulo\t\tEditorial\t\tGénero\t\tN° Páginas\tUnid. Disponibles");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        for(Libro book : libros){
            System.out.println(book.getID() + "\t\t" + book.getTitulo() + "\t\t" + book.getEditorial() + "\t\t" + book.getGenero() + "\t\t" + book.getnPaginas() + "\t\t" + book.getUnidDisponibles());
        }
    }
    
    static void boletasVistaPrevia(List<Prestamo> boletas, List<Cliente> clientes, List<Libro> libros, List<Empleado> usuarios, String tipoUsuario){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE BOLETAS");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        System.out.println("ID\t\tRecepcionista\tCliente\t\tLibro");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        if(tipoUsuario.equals("Administrador")){
            for(Prestamo ticket : boletas){
                System.out.print(ticket.getIDBoleta() + "\t\t");
                for(Empleado user : usuarios){
                    if(ticket.getIDRecepcionista() == IDActualUser){
                        System.out.print(user.getNombre() + "\t\t");
                        break;
                    }
                }
                for(Cliente client : clientes){
                    if(client.getID() == ticket.getIDCliente()){
                        System.out.print(client.getNombre() + "\t\t");
                        break;
                    }
                }
                for(Libro book : libros){
                    if(book.getID() == ticket.getIDLibro()){
                        System.out.println(book.getTitulo());
                        break;
                    }
                }
            }
            System.out.println("----------------------------------------");
        }else{
            IDActualUser = 0;
            for(Empleado user : usuarios){
                if(user.getNombre().equals(datosInicioSesion.get(1))) IDActualUser = user.getID();
            }
            for(Prestamo ticket : boletas){
                if(ticket.getIDRecepcionista() == IDActualUser){
                    System.out.print(ticket.getIDBoleta() + "\t\t");
                    for(Empleado user : usuarios){
                        if(user.getID() == IDActualUser){
                            System.out.print(user.getNombre() + "\t\t");
                            break;
                        }
                    }
                    for(Cliente client : clientes){
                        if(client.getID() == ticket.getIDCliente()){
                            System.out.print(client.getNombre() + "\t\t");
                            break;
                        }
                    }
                    for(Libro book : libros){
                        if(book.getID() == ticket.getIDLibro()){
                            System.out.println(book.getTitulo());
                            break;
                        }
                    }
                }
            }
            System.out.println("----------------------------------------");
        }
    }
    
    //FUNCIONES DE VISUALIZACIÓN DETALLADA DE DATOS
    static void recepcionistaVistaDetallada(List<Empleado> usuarios, int ID){
        for(Empleado user : usuarios){
            if(user.getID() == ID) user.mostrarUsuario();
        }
    }
    
    static void clienteVistaDetallada(List<Cliente> clientes, int ID){
        for(Cliente client : clientes){
            if(client.getID() == ID) client.mostrarCliente();
        }
    }
    
    static void libroVistaDetallada(List<Libro> libros, int ID){
        for(Libro book : libros){
            if(book.getID() == ID) book.mostrarLibro();
        }
    }
    
    static boolean boletaVistaDetallada(List<Prestamo> boletas, List<Empleado> usuarios, List<Cliente> clientes, List<Libro> libros, String nombreUsuario, int IDBoleta){
        int IDUsuario = 0;
        boolean ver = false;
        for(Empleado user : usuarios){
            if(user.getNombre().equals(nombreUsuario)){
                IDUsuario = user.getID();
            }
        }
        for(Prestamo ticket : boletas){
            if(ticket.getIDRecepcionista() == IDUsuario && ticket.getIDBoleta() == IDBoleta){
                ver = true;
                ticket.mostrarBoleta(usuarios, clientes, libros);
            }
        }
        if(!ver) System.out.println("ID no encontrado, intente nuevamente");
        else{
            System.out.print("Presione ENTER para continuar ");
            read.nextLine();//PARCHE
            read.nextLine();
        }
        return !ver;
    }
    
    static void consultaInformacionPersonal(String IDUsuario, List<Empleado> usuarios){
        for(Empleado user : usuarios){
            if(user.buscarCliente(IDUsuario, user)){
                //Mostrar información personal
                System.out.println("----------------------------------------");
                System.out.println("INFORMACIÓN PERSONAL");
                System.out.println("ID: " + user.getID());
                System.out.println("Nombre: " + user.getNombre());
                System.out.println("DNI: " + user.getDNI());
                System.out.println("Posición: " + user.getPosicion());
                System.out.println("Contraseña: " + user.getContrasena());
                System.out.print("Horario personal: Lunes a Sábado de ");
                if(user.getHoraInicio()>12) System.out.print((user.getHoraInicio()-12) + " pm ");
                else System.out.print(user.getHoraInicio() + " am ");
                System.out.print("a ");
                if(user.getHoraFin()>12) System.out.println((user.getHoraFin()-12) + " pm");
                else System.out.println(user.getHoraFin() + " am");
                break;
            }
        }
    }
}

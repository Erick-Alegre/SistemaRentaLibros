package com.mycompany.java.gestionrentalibros;

import Classes.Autor;
import static com.mycompany.java.gestionrentalibros.MainFunciones.*;
import static com.mycompany.java.gestionrentalibros.FuncionesLecturaCSV.*;
import static com.mycompany.java.gestionrentalibros.FuncionesEscrituraCSV.*;
import static com.mycompany.java.gestionrentalibros.FuncionesAdministrador.*;
import static com.mycompany.java.gestionrentalibros.FuncionesRecepcionista.*;
import static com.mycompany.java.gestionrentalibros.FuncionesMostrarDatos.*;

import Classes.Prestamo;
import Classes.Libro;
import Classes.Empleado;
import Classes.Cliente;
import Classes.historialCliente;
import com.opencsv.*;
import java.io.*;
import java.sql.*;
import java.util.*;

//Para hallar el filtro con varias cateegorías, se podría usar set para cada búsqueda y obtener los resultados de la intersección
//Max. de libros prestados: 6
//Las IDs de valor 0 indican que no hay valor
//NOTA: Las funciones de busqueda deben aceptar el ingreso de más valores para una mayor presición (Administrador)
//Añadir la función de "Confirmar devolución"
//La visualización de funciones

//ELIMINAR FUNCIONES DE MODIFICACION DE BASE DE DATOS

//En cada clase se implementarán funciones para modificar la base de datos
//El administrador debería poder modificar su información personal

public class GestionRentaLibros {
    
    static int option;
    static List<String> datosInicioSesion;
    static int IDActualUser;
    static boolean inicioSesionValido;
    static boolean band1 = true, band2 = true, band3 = true;
    static String[] fila;
    static CSVReader csvReader;
    
    public static void main(String[] args) {
        //Guardando la ruta del archivo CSV de usuarios, clientes, libros, boletas
        //Si no funciona, verificar la ubicación del archivo CSV
        //CAMBIAR POR LECTURA DE BASES DE DATOS MySQL
        String archCSVUser = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\empleados.csv";
        String archCSVClient = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\clientes.csv";
        String archCSVBook = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\libros.csv";
        String archCSVTicket = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\prestamos.csv";
        String archCSVAuthors = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\autores.csv";
        String archCSVClientRecord = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\historialClientes.csv";
        
        //ALMACENANDO LA BASE DE DATOS EN UNA LISTA DE OBJETOS DE SUS CLASES RESPECTIVAS
        //¿Como se trabajará con base de datos?
        List<Empleado> usuarios = LecturaBaseDatosUsuarios(archCSVUser);
        List<Cliente> clientes = LecturaBaseDatosClientes(archCSVClient);
        List<Libro> libros = LecturaBaseDatosLibros(archCSVBook);
        List<Prestamo> prestamos = LecturaBaseDatosBoletas(archCSVTicket);
        List<Autor> autores = LecturaBaseDatosAutores(archCSVAuthors);
        List<historialCliente> historialClientes = LecturaBaseDatosHistorialClientes(archCSVClientRecord);
        
        //PRUEBA DE USO DE BASE DE DATOS
        Statement stm;
        ResultSet rs;
        
        CConexion newConexion = new CConexion();
        newConexion.establecerConexion();
        
        //MENU PRINCIPAL
        do{
            option = mainMenu();
            switch(option){
                case 1:
                    //Gestion de recepcionista
                    datosInicioSesion = inicioSesion(usuarios);
                    for(Empleado user : usuarios){//Obtención del ID
                        if(datosInicioSesion.get(1).equals(user.getNombre()) && datosInicioSesion.get(2).equals(user.getContrasena())){
                            datosInicioSesion.add(Integer.toString(user.getID()));
                            break;
                        }
                    }
                    if("Administrador".equals(datosInicioSesion.get(0))){
                        //PARA EL ADMINISTRADOR
                        band1 = true;
                        do{
                            option = administradorMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    //GESTIÓN DE RECEPCIONISTAS
                                    band2 = true;
                                    do{
                                        recepcionistasVistaPrevia(usuarios);
                                        option = administradorGestionRecepcionistas();
                                        switch(option){
                                            case 1:
                                                //Ver detalles
                                                int selectRecepcionista = administradorSeleccionRecepcionista(usuarios); //selectRecepcionista: ID del recepcionista buscado
                                                recepcionistaVistaDetallada(usuarios, selectRecepcionista);
                                                option = administradorVerDetallesRecepcionista();
                                                switch(option){
                                                    case 1:
                                                        //Modificar nombre
                                                        administradorModificarNombreRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 2:
                                                        //Modificar DNI
                                                        administradorModificarDNIRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 3:
                                                        //Modificar posición
                                                        administradorModificarPosicionRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 4:
                                                        //Modificar contraseña
                                                        administradorModificarContrasenaRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 5:
                                                        //Modificar horario
                                                        administradorModificarHorarioRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 0:
                                                        band2 = true;
                                                }
                                                break;
                                            case 2:
                                                //Añadir
                                                administradorAnadirRecepcionista(usuarios);
                                                break;
                                            case 3:
                                                //Eliminar
                                                administradorEliminarRecepcionista(usuarios);
                                                break;
                                            case 4:
                                                //Buscar
                                                String searchNombre;
                                                int searchDNI, searchHoraInicio, searchHoraFin;
                                                System.out.println("Ingrese la información del empleado (Caso contrario ingrese '0')");
                                                //Nombre,DNI,Posicion,Contrasena,horaInicio,horaFin
                                                System.out.print("Ingrese el nombre del empleado: ");
                                                searchNombre = read.nextLine();
                                                System.out.print("Ingrese el DNI del empleado: ");
                                                searchDNI = Integer.parseInt(read.nextLine());
                                                System.out.print("Ingrese la hora del inicio de turno del empleado: ");
                                                searchHoraInicio = Integer.parseInt(read.nextLine());
                                                System.out.print("Ingrese la hora del fin de turno del empleado: ");
                                                searchHoraFin = Integer.parseInt(read.nextLine());
                                                for(Empleado user : usuarios){
                                                    if(user.getPosicion().equals("Recepcionista")){
                                                        boolean foundUser = true;
                                                        if(!searchNombre.equals("0") && !user.getNombre().equals(searchNombre)) foundUser = false;
                                                        if(searchDNI != 0 && user.getDNI() != searchDNI) foundUser = false;
                                                        if(searchHoraInicio != 0 && user.getHoraInicio() != searchHoraInicio) foundUser = false;
                                                        if(searchHoraFin != 0 && user.getHoraFin() != searchHoraFin) foundUser = false;
                                                        if(foundUser){
                                                            recepcionistaVistaDetallada(usuarios, user.getID());
                                                            System.out.print("Presione ENTER par continuar");
                                                            read.nextLine();
                                                        }
                                                    }
                                                }
                                                break;
                                            case 5:
                                                //Filtrar
                                                int filterHoraInicio, filterHoraFin;
                                                System.out.println("1.- Filtrar por horario");
                                                System.out.println("0.- Volver");
                                                option = seleccionOpcion(0,1);
                                                if(option == 1){
                                                    System.out.println("FILTRADO POR INTERVALO DE HORARIO");
                                                    System.out.print("Ingrese la hora de inicio para el intervalo: ");
                                                    filterHoraInicio = Integer.parseInt(read.nextLine());
                                                    System.out.print("Ingrese la hora de fin para el intervalo: ");
                                                    filterHoraFin = Integer.parseInt(read.nextLine());
                                                    for(Empleado user : usuarios){
                                                        if(user.getPosicion().equals("Recepcionista") && user.getHoraInicio() >= filterHoraInicio && user.getHoraFin() <= filterHoraFin){
                                                            recepcionistaVistaDetallada(usuarios, user.getID());
                                                            System.out.print("Presione ENTER par continuar");
                                                            read.nextLine();
                                                        }
                                                    }
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                        //actualizarBaseDatosUsuarios(archCSVUser, usuarios); //AUTOMATICO, SIN UTILIZAR
                                    }while(band2);
                                    break;
                                case 2:
                                    //GESTION DE CLIENTES
                                    band2 = true;
                                    do{
                                        clientesVistaPrevia(clientes);
                                        option = administradorGestionClientes();
                                        switch(option){
                                            case 1:
                                                //Ver detalles de cliente
                                                int idActualCliente;
                                                System.out.println("----------------------------------------");
                                                System.out.println("Ingrese el ID del cliente: ");
                                                idActualCliente = Integer.parseInt(read.nextLine());
                                                clienteVistaDetallada(clientes, idActualCliente);
                                                option = recepcionistaVerDetallesCliente(clientes);
                                                if(option == 1) recepcionistaMostrarHistorialCliente(clientes, historialClientes, libros, idActualCliente);
                                                break;
                                            case 2:
                                                //Añadir cliente
                                                recepcionistaAnadirCliente(clientes, historialClientes);
                                                break;
                                            case 3:
                                                //Eliminar cliente
                                                administradorEliminarCliente(clientes);
                                                break;
                                            case 4:
                                                //Buscar clientes
                                                band3 = true;
                                                do{
                                                    option = administradorBuscarClientes(clientes);
                                                    if(option == 0) band3 = false;
                                                    
                                                }while(band3);
                                                break;
                                            case 5:
                                                //Filtrar clientes
                                                option = administradorMenuFiltrarClientes();
                                                switch(option){
                                                    case 1:
                                                        int minCantLibros, maxCantLibros;
                                                        System.out.println("FILTRADO POR INTERVALO DE CANTIDA DE LIBROS PRESTADOS");
                                                        System.out.print("Ingrese el mínimo de cantidad de libros: ");
                                                        minCantLibros = Integer.parseInt(read.nextLine());
                                                        System.out.print("Ingrese el máximo de cantidad de libros: ");
                                                        maxCantLibros = Integer.parseInt(read.nextLine());
                                                        for(Cliente client : clientes){
                                                            if(client.getCantLibrosPrestados() >= minCantLibros && client.getCantLibrosPrestados() <= maxCantLibros){
                                                                clienteVistaDetallada(clientes, client.getID());
                                                                System.out.print("Presione ENTER par continuar");
                                                                read.nextLine();
                                                            }
                                                        }
                                                        break;
                                                    case 2:
                                                        administradorFiltrarClientes(clientes, null, "estadoSancion", administradorIngresoDataFiltro("estadoSancion"));
                                                        break;
                                                    case 0:
                                                        //
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 3:
                                    //GESTIÓN DE LIBROS
                                    band2 = true;
                                    do{
                                        librosVistaPrevia(libros);
                                        option = recepcionistaGestionLibros();
                                        switch(option){
                                            case 1:
                                                int idActualLibro;
                                                System.out.println("----------------------------------------");
                                                System.out.println("Ingrese el ID del libro: ");
                                                idActualLibro = Integer.parseInt(read.nextLine());
                                                libroVistaDetallada(libros, idActualLibro);
                                                System.out.println("----------------------------------------");
                                                System.out.println("1.- Modificar título");
                                                System.out.println("2.- Modificar fecha de publicación");
                                                System.out.println("3.- Modificar editorial");
                                                System.out.println("4.- Modificar género");
                                                System.out.println("5.- Modificar numero de páginas");
                                                System.out.println("6.- Modificar unidades disponibles");
                                                System.out.println("0.- Volver");
                                                option = seleccionOpcion(0,6);
                                                switch(option){
                                                    case 1:
                                                        administradorModificarNombreLibro(idActualLibro, libros);
                                                        break;
                                                    case 2:
                                                        administradorModificarFechaLibro(idActualLibro, libros);
                                                        break;
                                                    case 3:
                                                        administradorModificarEditorialLibro(idActualLibro, libros);
                                                        break;
                                                    case 4:
                                                        administradorModificarGeneroLibro(idActualLibro, libros);
                                                        break;
                                                    case 5:
                                                        administradorModificarNPaginasLibro(idActualLibro, libros);
                                                        break;
                                                    case 6:
                                                        administradorModificarUnidDisponiblesLibro(idActualLibro, libros);
                                                        break;
                                                }
                                                break;
                                            case 2:
                                                administradorAnadirLibro(libros);
                                                break;
                                            case 3:
                                                administradorEliminarLibro(libros);
                                                break;
                                            case 4:
                                                //Buscar
                                                band2 = true;
                                                do{
                                                    option = recepcionistaBuscarLibros(clientes, libros);
                                                    if(option == 0) band2 = false;
                                                }while(band2);
                                                break;
                                            case 5:
                                                //Filtrar
                                                option = recepcionistaMenuFiltrarLibros();
                                                switch(option){
                                                    case 1:
                                                        //FechaPublicacion
                                                        option = recepcionistaSeleccionCriterioFiltro("fechaPublicacion");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Anterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Posterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                            }
                                                        break;
                                                    case 2:
                                                        //Editorial
                                                        recepcionistaFiltrarLibros(libros, null, "editorial", recepcionistaIngresoDataFiltro("editorial"));
                                                        break;
                                                    case 3:
                                                        //Genero
                                                        recepcionistaFiltrarLibros(libros, null, "genero", recepcionistaIngresoDataFiltro("genero"));
                                                        break;
                                                    case 4:
                                                        //N Paginas
                                                        option = recepcionistaSeleccionCriterioFiltro("nPaginas");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Menor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Mayor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                            }
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 4:
                                    //CONSULTA DE INFORMACIÓN PERSONAL
                                    consultaInformacionPersonal(datosInicioSesion.get(3), usuarios);
                                    System.out.println("1.- Modificar información personal");
                                    System.out.println("0.- Volver");
                                    option = seleccionOpcion(0,1);
                                    if(option == 1){
                                        int selectEmpleado = Integer.parseInt(datosInicioSesion.get(3));
                                        option = administradorVerDetallesRecepcionista();
                                        switch(option){
                                            case 1:
                                                //Modificar nombre
                                                administradorModificarNombreRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 2:
                                                //Modificar DNI
                                                administradorModificarDNIRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 3:
                                                //Modificar contraseña
                                                administradorModificarContrasenaRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 4:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 5:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 0:
                                                band2 = true;
                                        }
                                    }
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                            }
                        }while(band1);
                    }else{
                        //PARA EL RECEPCIONISTA
                        band1 = true;
                        do{
                            option = recepcionistaMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    //Gestión de clientes
                                    band2 = true;
                                    do{
                                        clientesVistaPrevia(clientes);
                                        option = recepcionistaGestionClientes();
                                        switch(option){
                                            case 1:
                                                //Ver detalles de un cliente
                                                int idActualCliente;
                                                System.out.println("----------------------------------------");
                                                System.out.println("Ingrese el ID del cliente: ");
                                                idActualCliente = Integer.parseInt(read.nextLine());
                                                clienteVistaDetallada(clientes, idActualCliente);
                                                option = recepcionistaVerDetallesCliente(clientes);
                                                if(option == 1) recepcionistaMostrarHistorialCliente(clientes, historialClientes, libros, idActualCliente);
                                                break;
                                            case 2:
                                                //Añadir cliente
                                                recepcionistaAnadirCliente(clientes, historialClientes);
                                                break;
                                            case 3:
                                                //Eliminar cliente
                                                administradorEliminarCliente(clientes);
                                                break;
                                            case 4:
                                                //Buscar clientes
                                                
                                                break;
                                            case 5:
                                                //Filtrar clientes
                                                
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 2:
                                    //Consulta de libros
                                    band2 = true;
                                    do{
                                        librosVistaPrevia(libros);
                                        option = recepcionistaGestionLibros();
                                        switch(option){
                                            case 1:
                                                //Buscar
                                                band2 = true;
                                                do{
                                                    option = recepcionistaBuscarLibros(clientes, libros);
                                                    if(option == 0) band2 = false;
                                                }while(band2);
                                                break;
                                            case 2:
                                                //Filtrar
                                                option = recepcionistaMenuFiltrarLibros();
                                                switch(option){
                                                    case 1:
                                                        //FechaPublicacion
                                                        option = recepcionistaSeleccionCriterioFiltro("fechaPublicacion");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Anterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Posterior", "fechaPublicacion", recepcionistaIngresoDataFiltro("fechaPublicacion"));
                                                                    break;
                                                            }
                                                        break;
                                                    case 2:
                                                        //Editorial
                                                        recepcionistaFiltrarLibros(libros, null, "editorial", recepcionistaIngresoDataFiltro("editorial"));
                                                        break;
                                                    case 3:
                                                        //Genero
                                                        recepcionistaFiltrarLibros(libros, null, "genero", recepcionistaIngresoDataFiltro("genero"));
                                                        break;
                                                    case 4:
                                                        //N Paginas
                                                        option = recepcionistaSeleccionCriterioFiltro("nPaginas");
                                                        switch(option){
                                                                case 1:
                                                                    //Menor
                                                                    recepcionistaFiltrarLibros(libros, "Menor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 2:
                                                                    //Igual
                                                                    recepcionistaFiltrarLibros(libros, "Igual", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                                case 3:
                                                                    //Mayor
                                                                    recepcionistaFiltrarLibros(libros, "Mayor", "nPaginas", recepcionistaIngresoDataFiltro("nPaginas"));
                                                                    break;
                                                            }
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 3:
                                    //Realizar préstamo
                                    band2 = true;
                                    boolean aux;
                                    do{
                                        String actualClient, actualBook;
                                        int IDCliente, IDLibro;
                                        System.out.print("Ingrese el nombre del cliente: ");
                                        actualClient = read.nextLine();
                                        //Verificar que el cliente esté en el sistema
                                        IDCliente = busquedaNombreCliente(clientes, actualClient);
                                        if(IDCliente == 0){
                                            System.out.println("El cliente no se encuentra registrado");
                                            System.out.println("1.- Iniciar nuevo préstamo");
                                            System.out.println("0.- Volver al menú principal");
                                            do{
                                                option = Integer.parseInt(read.nextLine());
                                                if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                            }while(option<0 || option >1);
                                            if(option == 0){
                                                break;
                                            }
                                        }else{
                                            //Verificar que el cliente no tenga deudas pendientes
                                            aux = false;
                                            for(Cliente client : clientes){
                                                if(actualClient.equals(client.getNombre()) && client.getEstadoSancion()) aux = true;
                                            }
                                            if(aux){
                                                System.out.println("El cliente tiene libros pendientes de devolución");
                                                System.out.println("1.- Iniciar nuevo préstamo");
                                                System.out.println("0.- Volver al menú principal");
                                                do{
                                                    option = Integer.parseInt(read.nextLine());
                                                    if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                }while(option<0 || option >1);
                                                if(option == 0){
                                                    break;
                                                }
                                            }else{
                                                System.out.print("Ingrese el nombre del libro a prestar: ");
                                                actualBook = read.nextLine();
                                                //Verificar que el libro esté en el sistema
                                                IDLibro = busquedaNombreLibro(libros, actualBook);
                                                if(IDLibro == 0){
                                                    System.out.println("El libro no se encuentra registrado");
                                                    System.out.println("1.- Iniciar nuevo préstamo");
                                                    System.out.println("0.- Volver al menú principal");
                                                    do{
                                                        option = Integer.parseInt(read.nextLine());
                                                        if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                    }while(option<0 || option >1);
                                                    if(option == 0){
                                                        break;
                                                    }
                                                }else{
                                                    //Verificar si hay unidades disponibles del libro
                                                    aux = false;
                                                    for(Libro book : libros){
                                                        if(actualBook.equals(book.getTitulo()) && book.getUnidDisponibles()==0) aux = true;
                                                    }
                                                    if(aux){
                                                        System.out.println("No hay unidades disponible del libro");
                                                        System.out.println("1.- Iniciar nuevo préstamo");
                                                        System.out.println("0.- Volver al menú principal");
                                                        do{
                                                            option = Integer.parseInt(read.nextLine());
                                                            if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                        }while(option<0 || option >1);
                                                        if(option == 0){
                                                            break;
                                                        }
                                                    }else{
                                                        if(ConfirmarModificacion()){
                                                            String fechaActual = obtenerFechaActual();
                                                            //Se añade el préstamo
                                                            Prestamo newLending = new Prestamo(generacionIDAleatorioPrestamo(prestamos, "Prestamo"), Integer.parseInt(datosInicioSesion.get(3)), IDCliente, IDLibro);
                                                            prestamos.add(newLending);
                                                            //Se añade al historial del cliente
                                                            historialCliente newRecord = new historialCliente(IDCliente, IDLibro, fechaActual, obtenerFechaDevolucion(fechaActual), "0");
                                                            historialClientes.add(newRecord);
                                                            //Se añade una unidad a la catida de libros prestados del cliente
                                                            for(Cliente client : clientes){
                                                                if(client.getID() == IDCliente) client.setCantLibrosPrestados(client.getCantLibrosPrestados()+1);
                                                            }
                                                            //Reducción de una unidad del libro
                                                            for(Libro book : libros){
                                                                if(book.getID() == IDLibro) book.setUnidDisponibles(book.getUnidDisponibles()-1);
                                                            }
                                                            System.out.println("El préstamo se realizó correctamente");
                                                        }else{
                                                            System.out.println("El préstamo no se ha realizado");
                                                        }
                                                        band2 = false;
                                                    }
                                                }
                                            }
                                        }
                                    }while(band2);
                                    break;
                                case 4:
                                    //Confirmar devolución
                                    band2 = true;
                                    do{
                                        String actualClient, actualBook;
                                        int IDCliente, IDLibro;
                                        System.out.print("Ingrese el nombre del cliente: ");
                                        actualClient = read.nextLine();
                                        IDCliente = busquedaNombreCliente(clientes, actualClient);
                                        //Verificar que el cliente esté en el sistema
                                        if(IDCliente == 0){
                                            System.out.println("El cliente no se encuentra registrado");
                                            System.out.println("1.- Iniciar nuevo proceso de devolución");
                                            System.out.println("0.- Volver al menú principal");
                                            do{
                                                option = Integer.parseInt(read.nextLine());
                                                if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                            }while(option<0 || option >1);
                                            if(option == 0) break;
                                        }else{
                                            //Se muestran los libros pendientes de devolucion
                                            aux = false;
                                            System.out.println("----------------------------------------");
                                            System.out.println("LIBROS PENDIENTES DE DEVOLUCIÓN: ");
                                            System.out.println("ID\t\tLibro\t\tFecha de Préstamo");
                                            for(historialCliente record : historialClientes){
                                                if(record.getIDCliente() == IDCliente && record.getFechaRealDevolucion().equals("0")){
                                                    System.out.println(record.getIDLibro() + "\t\t" + busquedaIDLibro(libros, record.getIDLibro()) + "\t\t" + record.getFechaPrestamo());
                                                    aux = true;
                                                }
                                            }
                                            System.out.println("----------------------------------------");
                                            if(!aux){
                                                System.out.println("No se encontraron libros pendientes de devolución");
                                            }else{
                                                System.out.print("Ingrese el ID del libro que se va a devolver: ");
                                                IDLibro = Integer.parseInt(read.nextLine());
                                                //Verificar que el libro esté en el sistema
                                                actualBook = busquedaIDLibro(libros, IDLibro);
                                                if(actualBook.equals("")){
                                                    System.out.println("El libro no se encuentra registrado");
                                                    System.out.println("1.- Iniciar nuevo préstamo");
                                                    System.out.println("0.- Volver al menú principal");
                                                    do{
                                                        option = Integer.parseInt(read.nextLine());
                                                        if(option<0 || option >1) System.out.println("Opción inválida, intente nuevamente...");
                                                    }while(option<0 || option >1);
                                                    if(option == 0){
                                                        break;
                                                    }
                                                }else{
                                                    //Se confirma la devolucion
                                                    if(ConfirmarModificacion()){
                                                        //Se actualiza la fecha real de devolucion del libro
                                                        for(historialCliente record : historialClientes){
                                                            if(record.getIDCliente() == IDCliente && record.getIDLibro() == IDLibro) record.setFechaRealDevolucion(obtenerFechaActual());
                                                            break;
                                                        }
                                                        //Se reduce una unidad a la cantidad de libros prestados del cliente
                                                        for(Cliente client : clientes){
                                                            if(client.getID() == IDCliente) client.setCantLibrosPrestados(client.getCantLibrosPrestados()-1);
                                                        }
                                                        //Aumento de una unidad del libro
                                                        for(Libro book : libros){
                                                            if(book.getID() == IDLibro) book.setUnidDisponibles(book.getUnidDisponibles()+1);
                                                            break;
                                                        }
                                                        System.out.println("La devolución se realizó correctamente");
                                                    }else{
                                                        System.out.println("La devolución no se ha realizado");
                                                    }
                                                    band2 = false;
                                                }
                                            }
                                        }
                                        
                                    }while(band2);
                                    break;
                                case 5:
                                    //Ver información personal
                                    consultaInformacionPersonal(datosInicioSesion.get(3), usuarios);
                                    System.out.println("1.- Modificar información personal");
                                    System.out.println("2.- Ver préstamos generados");
                                    System.out.println("0.- Volver");
                                    option = seleccionOpcion(0,2);
                                    if(option == 1){
                                        int selectEmpleado = Integer.parseInt(datosInicioSesion.get(3));
                                        option = administradorVerDetallesRecepcionista();
                                        switch(option){
                                            case 1:
                                                //Modificar nombre
                                                administradorModificarNombreRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 2:
                                                //Modificar DNI
                                                administradorModificarDNIRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 3:
                                                //Modificar contraseña
                                                administradorModificarContrasenaRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 4:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 5:
                                                //Modificar horario
                                                administradorModificarHorarioRecepcionista(selectEmpleado, usuarios);
                                                break;
                                            case 0:
                                                band2 = true;
                                        }
                                    }else if(option == 2){
                                        //Mostrar historial de préstamos generadas
                                        boletasVistaPrevia(prestamos, clientes, libros, usuarios, datosInicioSesion.get(0));
                                        System.out.println("1.- Ver detalles de boletas por ID");
                                        System.out.println("0.- Volver");
                                        option = seleccionOpcion(0,1);
                                        switch(option){
                                            case 1:
                                                band2 = true;
                                                do{
                                                    System.out.print("Ingrese la ID de la boleta: ");
                                                    band2 = boletaVistaDetallada(prestamos, usuarios, clientes, libros, datosInicioSesion.get(1), Integer.parseInt(read.nextLine()));
                                                }while(band2);
                                                break;
                                            case 0:

                                                break;
                                        }
                                    }
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                                    break;
                            }
                        }while(band1);
                    }
                    break;
                case 0:
                    inicioSesionValido = false;
                    break;
            }
        }while(inicioSesionValido);
        
        System.out.println("ALL WORKING");
    }
}

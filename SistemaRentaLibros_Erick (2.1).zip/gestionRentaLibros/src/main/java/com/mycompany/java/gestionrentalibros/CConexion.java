package com.mycompany.java.gestionrentalibros;
import java.sql.*;

public class CConexion {
    Connection con = null;
    String user = "root";
    String password = "12345678";
    String bd = "baseDatosRentaLibros";
    String url = "jdbc:mysql://localhost:3306/baseDatosRentaLibros";

    public CConexion() {
    }
    
    public Connection establecerConexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);
            System.out.println("Se conectó correctamente a las bases de datos");
        }catch(Exception e){
            System.out.println("Error al conectar a la base de datos");
        }
        return con;
    }
}

package com.mycompany.java.gestionrentalibros;

import Classes.Empleado;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.util.List;

public class FuncionesEscrituraCSV {
    //FUNCIONES DE ESCRITURA DE CSV (SOBREESCRITURA) (AUN NO SE UTILIZAN)
    static void actualizarBaseDatosUsuarios(String CSVLocation, List<Empleado> usuarios){
        //Sobreescritura de la base de datos (Falta añadir ajustes de escritura)
        try {
            CSVWriter csvWriter = new CSVWriter(new FileWriter(CSVLocation, false), ',', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER,CSVWriter.DEFAULT_LINE_END );
            csvWriter.writeNext(new String[] {"ID","Nombre","DNI","Posicion","Contrasena","horaInicio","horaFin"});
            for(Empleado user : usuarios){
                
                csvWriter.writeNext(new String[] {Integer.toString(user.getID()), user.getNombre(), Integer.toString(user.getDNI()), user.getPosicion(), user.getContrasena(), Integer.toString(user.getHoraInicio()), Integer.toString(user.getHoraFin())});
            }
            csvWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

package Classes;

import java.text.SimpleDateFormat;
import java.util.Date;

public class historialCliente {
    private int IDCliente;
    private int IDLibro;
    private Date fechaPrestamo;
    private Date fechaDevolucion;

    public historialCliente(int IDCliente, int IDLibro, Date fechaPrestamo, Date fechaDevolucion) {
        this.IDCliente = IDCliente;
        this.IDLibro = IDLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
    }

    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int IDCliente) {
        this.IDCliente = IDCliente;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }

    public Date getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Date fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public Date getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
    
    //
    
}

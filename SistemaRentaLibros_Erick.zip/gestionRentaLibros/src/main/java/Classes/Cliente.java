package Classes;

public class Cliente {
    private int ID;
    private String Nombre;
    private int DNI;
    private int Telefono;
    private int cantLibrosPrestados;
    private boolean estadoSancion;

    public Cliente(int ID, String Nombre, int DNI, int Telefono, int cantLibrosPrestados, String estadoSancion) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.DNI = DNI;
        this.Telefono = Telefono;
        this.cantLibrosPrestados = cantLibrosPrestados;
        if(estadoSancion.equals("Si")) this.estadoSancion = true;
        else this.estadoSancion = false;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public int getCantLibrosPrestados() {
        return cantLibrosPrestados;
    }

    public void setCantLibrosPrestados(int cantLibrosPrestados) {
        this.cantLibrosPrestados = cantLibrosPrestados;
    }
    
    public boolean getEstadoSancion() {
        return estadoSancion;
    }

    public void setEstadoSancion(boolean estadoSancion) {
        this.estadoSancion = estadoSancion;
    }
    
    //Otros métodos o funciones
    public void mostrarCliente(){
        String eSancion;
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DEL CLIENTE");
        System.out.println("ID: " + this.ID);
        System.out.println("Nombre: " + this.Nombre);
        System.out.println("DNI: " + this.DNI);
        System.out.println("Teléfono: " + this.Telefono);
        System.out.println("Cantidad de libros en préstamo: " + this.cantLibrosPrestados);
        eSancion = (this.estadoSancion==true)?"ACTIVO":"INACTIVO";
        System.out.println("Estado de sanción: " + eSancion);
    }
    
    public boolean buscarCliente(String clientData, Cliente client){
        //Si el tipo de dato se puede convertir a int, buscar en todos los datos, caso contrario se busca solo en los nombres
        if(clientData.matches("[0-9]+")){
            return this.Nombre.equals(clientData) || this.DNI == Integer.parseInt(clientData) || this.Telefono == Integer.parseInt(clientData);
        }else{
            return this.Nombre.equals(clientData);
        }
    }
    
    public void anadirCliente(){
        
    }
    
    public void eliminarCliente(){
        
    }
    
    
}
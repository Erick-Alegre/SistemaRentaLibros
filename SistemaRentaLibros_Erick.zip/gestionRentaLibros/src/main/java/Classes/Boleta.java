package Classes;

import java.util.Date;
import java.util.List;

/*
Se considera cambiar el nombre de la clase a prestamo, ya que al registrarse la fecha en que se devolvio el libro (fechaDevolucion), además de
la fecha estimada de devolucion (fechaEstimadaDevolucion), es el nombre que mejor lo describe. Ademas de mostrar el historial de un cliente, 
esta clase podrá generar la boleta.
*/

public class Boleta {
    private int IDBoleta;
    private int IDRecepcionista;
    private int IDCliente;
    private int IDLibro;
    private Date fechaPrestamo;
    private Date fechaDevolucion;

    public Boleta(int IDBoleta, int IDRecepcionista, int IDCliente, int IDLibro, Date fechaPrestamo, Date fechaDevolucion) {
        this.IDBoleta = IDBoleta;
        this.IDRecepcionista = IDRecepcionista;
        this.IDCliente = IDCliente;
        this.IDLibro = IDLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
    }
    
    public int getIDBoleta() {
        return IDBoleta;
    }

    public void setIDBoleta(int IDBoleta) {
        this.IDBoleta = IDBoleta;
    }

    public int getIDRecepcionista() {
        return IDRecepcionista;
    }

    public void setIDRecepcionista(int IDRecepcionista) {
        this.IDRecepcionista = IDRecepcionista;
    }

    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int IDCliente) {
        this.IDCliente = IDCliente;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }

    public Date getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Date fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public Date getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
    
    public void anadirBoleta(List<Boleta> boletas, int newIDBoleta, int newIDRecepcionista, int newIDCliente, int newIDLibro, Date newFechaPrestamo, Date newFechaDevolucion){
        Boleta newTicket = new Boleta(newIDBoleta, newIDRecepcionista, newIDCliente, newIDLibro, newFechaPrestamo, newFechaDevolucion);
        boletas.add(newTicket);
    }
    
    public void mostrarBoleta(List<Usuario> usuarios, List<Cliente> clientes, List<Libro> libros){
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DE LA BOLETA");
        System.out.println("ID de la boleta: " + this.IDBoleta);
        System.out.print("Nombre del recepcionista: ");
        for(Usuario user : usuarios){
            if(user.getID() == this.IDRecepcionista){
                System.out.println(user.getNombre());
            }
        }
        System.out.print("Nombre del cliente: ");
        for(Cliente client : clientes){
            if(client.getID() == this.IDCliente){
                System.out.println(client.getNombre());
            }
        }
        System.out.print("Nombre del libro: ");
        for(Libro book : libros){
            if(book.getID() == this.IDLibro){
                System.out.println(book.getTitulo());
            }
        }
        System.out.println("Fecha de préstamo: " + this.fechaPrestamo);
        System.out.println("Fecha estimada para la devolución: " + this.fechaDevolucion);
    }
}

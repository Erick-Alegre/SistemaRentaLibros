package Classes;

import java.util.List;

public class Usuario {

    private Integer ID;
    private String nombre;
    private Integer DNI;
    private String posicion;
    private String contrasena;
    private Integer horaInicio;
    private Integer horaFin;

    public Usuario(int ID, String nombre, int DNI, String posicion, String contrasena, int horaInicio, int horaFin) {
        this.ID = ID;
        this.nombre = nombre;
        this.DNI = DNI;
        this.posicion = posicion;
        this.contrasena = contrasena;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public int getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(int horaInicio) {
        this.horaInicio = horaInicio;
    }

    public int getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(int horaFin) {
        this.horaFin = horaFin;
    }
    
    //Otros métodos o funciones
    public void anadirUsuario(List<Usuario> usuarios, int newID, String newNombre, int newDNI, String newPosicion, String newContrasena, int newHoraInicio, int newHoraFin){
        Usuario newUser = new Usuario(newID, newNombre, newDNI, newPosicion, newContrasena, newHoraInicio, newHoraFin);
        usuarios.add(newUser);
    }
    
    public void eliminarUsuario(List<Usuario> usuarios, Usuario user){
        usuarios.remove(user);
    }
    
    public void mostrarUsuario(){
        System.out.println("----------------------------------------");
        System.out.println("INFORMACIÓN DEL RECEPCIONISTA " + this.nombre.toUpperCase());
        System.out.println("ID: " + this.ID);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("DNI: " + this.DNI);
        System.out.println("Contraseña: " + this.contrasena);
        System.out.println("Horario: " + mostrarHorarioFormato(this.horaInicio, this.horaFin));
    }
    
    //Funciones adicionales
    public String mostrarHorarioFormato(int horaInicio, int horaFin){
        String horario = "Lunes a Sábado de ";
        if(horaInicio<=12) horario = horario + (horaInicio + "am a ");
        else horario = horario + ((horaInicio - 12) + "pm a ");
        if(horaFin<=12) horario = horario + horaFin + "am";
        else horario = horario + (horaFin - 12) + "pm";
        return horario;
    }
}

package Classes;

public class Canasta {
    //Almacena los libros en préstamo de un cliente
}

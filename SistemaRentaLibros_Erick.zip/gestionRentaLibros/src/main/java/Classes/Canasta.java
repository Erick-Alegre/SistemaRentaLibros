package Classes;

import java.util.ArrayList;
import java.util.List;

public class Canasta {
    private int IDCliente;
    private int IDLibro;
    private List<Integer> IDLibrosEnCanasta = new ArrayList<>();

    public Canasta(int IDCliente, int IDLibro, int Libro1, int Libro2, int Libro3, int Libro4, int Libro5, int Libro6) {
        this.IDCliente = IDCliente;
        this.IDLibro = IDLibro;
        if(Libro1 != 0) this.IDLibrosEnCanasta.add(Libro1);
        if(Libro2 != 0) this.IDLibrosEnCanasta.add(Libro2);
        if(Libro3 != 0) this.IDLibrosEnCanasta.add(Libro3);
        if(Libro4 != 0) this.IDLibrosEnCanasta.add(Libro4);
        if(Libro5 != 0) this.IDLibrosEnCanasta.add(Libro5);
        if(Libro6 != 0) this.IDLibrosEnCanasta.add(Libro6);
    }

    public int getIDCliente() {
        return IDCliente;
    }

    public void setIDCliente(int IDCliente) {
        this.IDCliente = IDCliente;
    }

    public int getIDLibro() {
        return IDLibro;
    }

    public void setIDLibro(int IDLibro) {
        this.IDLibro = IDLibro;
    }

    public List<Integer> getIDLibrosEnCanasta() {
        return IDLibrosEnCanasta;
    }

    public void setIDLibrosEnCanasta(List<Integer> IDLibrosEnCanasta) {
        this.IDLibrosEnCanasta = IDLibrosEnCanasta;
    }
    
    //Otras funciones
    
}

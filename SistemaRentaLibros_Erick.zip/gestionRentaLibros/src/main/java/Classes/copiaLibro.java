package Classes;

public class copiaLibro {
    //PENDIENTE
    //Esta clase funciona como enlace entre libros y autores, y permite acceder a la informacion detallada del libro y su autor desde la boleta
}

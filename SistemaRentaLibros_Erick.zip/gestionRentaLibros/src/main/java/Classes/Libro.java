package Classes;

import java.util.Date;

public class Libro {
    private int ID;
    private String titulo;
    private Date fechaPublicacion;
    private String editorial;
    private String genero;
    private int nPaginas;
    private int unidDisponibles;

    public Libro(int ID, String titulo, Date fechaPublicacion, String editorial, String genero, int nPaginas, int unidDisponibles) {
        this.ID = ID;
        this.titulo = titulo;
        this.fechaPublicacion = fechaPublicacion;
        this.editorial = editorial;
        this.genero = genero;
        this.nPaginas = nPaginas;
        this.unidDisponibles = unidDisponibles;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getnPaginas() {
        return nPaginas;
    }

    public void setnPaginas(int nPaginas) {
        this.nPaginas = nPaginas;
    }

    public int getUnidDisponibles() {
        return unidDisponibles;
    }

    public void setUnidDisponibles(int unidDisponibles) {
        this.unidDisponibles = unidDisponibles;
    }
    
    
}

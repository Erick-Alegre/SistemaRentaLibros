package com.mycompany.java.gestionrentalibros;

import static com.mycompany.java.gestionrentalibros.MainFunciones.*;
import static com.mycompany.java.gestionrentalibros.FuncionesLecturaCSV.*;
import static com.mycompany.java.gestionrentalibros.FuncionesEscrituraCSV.*;
import static com.mycompany.java.gestionrentalibros.FuncionesAdministrador.*;
import static com.mycompany.java.gestionrentalibros.FuncionesRecepcionista.*;
import static com.mycompany.java.gestionrentalibros.FuncionesMostrarDatos.*;

import Classes.Boleta;
import Classes.Libro;
import Classes.Usuario;
import Classes.Cliente;
import Classes.Canasta;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.SimpleDateFormat;

//En un inicio guardar los datos de las bases de datos en cada clase, para acceder a ellos y modificarlos libremente
//En el momento de modificar un dato en el objeto de una clase, al finalizar llevar esos cambios a las bases de datos
//Dos usuarios pueden tener el mismo nombre, pero no el mismo usuario (SUM da correos para iniciar sesión)
//Para hallar el filtro con varias cateegorías, se podría usar set para cada búsqueda y obtener los resultados de la intersección
//Max. de libros prestados: 6
//Las IDs de valor 0 indican que no hay valor

//ELIMINAR FUNCIONES DE MODIFICACION DE BASE DE DATOS

//HAY VARIAS COSAS QUE SE PUEDEN OPTIMIZAR


public class GestionRentaLibros {

    static SimpleDateFormat formato = new SimpleDateFormat("dd-mm-yyyy");
    
    static int option;
    static List<String> datosInicioSesion;
    static int IDActualUser;
    static boolean inicioSesionValido;
    static boolean band1 = true, band2 = true, band3 = true;
    static String[] fila;
    static CSVReader csvReader;
    
    public static void main(String[] args) {
        //Guardando la ruta del archivo CSV de usuarios, clientes, libros, boletas
        //Si no funciona, verificar la ubicación del archivo CSV
        String archCSVUser = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\usuarios.csv";
        String archCSVClient = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\clientes.csv";
        String archCSVBook = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\libros.csv";
        String archCSVTicket = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\boletas.csv";
        String archCSVShopCart = "C:\\Users\\user\\OneDrive\\Documentos\\BaseDatos\\canastas.csv";
        
        //ALMACENANDO LA BASE DE DATOS EN UNA LISTA DE OBJETOS DE SUS CLASES RESPECTIVAS
        List<Usuario> usuarios = LecturaBaseDatosUsuarios(archCSVUser);
        List<Cliente> clientes = LecturaBaseDatosClientes(archCSVClient);
        List<Libro> libros = LecturaBaseDatosLibros(archCSVBook);
        List<Boleta> boletas = LecturaBaseDatosBoletas(archCSVTicket);
        List<Canasta> canastas = LecturaBaseDatosCanastas(archCSVShopCart);
        
        //MENU PRINCIPAL
        do{
            option = mainMenu();
            switch(option){
                case 1:
                    datosInicioSesion = inicioSesion(usuarios);
                    if("Administrador".equals(datosInicioSesion.get(0))){
                        //PARA EL ADMINISTRADOR
                        band1 = true;
                        do{
                            option = administradorMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    band2 = true;
                                    do{
                                        recepcionistasVistaPrevia(usuarios);
                                        option = administradorGestionRecepcionistas();
                                        switch(option){
                                            case 1:
                                                //Ver detalles
                                                int selectRecepcionista = administradorSeleccionRecepcionista(usuarios); //selectRecepcionista: ID del recepcionista buscado
                                                recepcionistaVistaDetallada(usuarios, selectRecepcionista);
                                                option = administradorVerDetallesRecepcionista();
                                                switch(option){
                                                    case 1:
                                                        //Modificar nombre
                                                        administradorModificarNombreRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 2:
                                                        //Modificar DNI
                                                        administradorModificarDNIRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 3:
                                                        //Modificar posición
                                                        administradorModificarPosicionRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 4:
                                                        //Modificar contraseña
                                                        administradorModificarContrasenaRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 5:
                                                        //Modificar horario
                                                        administradorModificarHorarioRecepcionista(selectRecepcionista, usuarios);
                                                        break;
                                                    case 0:
                                                        band2 = true;
                                                }
                                                break;
                                            case 2:
                                                //Añadir
                                                administradorAnadirRecepcionista(usuarios);
                                                break;
                                            case 3:
                                                //Eliminar
                                                administradorEliminarRecepcionista(usuarios);
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                        //actualizarBaseDatosUsuarios(archCSVUser, usuarios); //AUTOMATICO, SIN UTILIZAR
                                    }while(band2);
                                    break;
                                case 2:
                                    band2 = true;
                                    do{
                                        clientesVistaPrevia(clientes);
                                        option = administradorGestionClientes();
                                        switch(option){
                                            case 1:
                                                //Buscar clientes
                                                band3 = true;
                                                do{
                                                    option = administradorBuscarClientes(clientes);
                                                    if(option == 0) band3 = false;
                                                }while(band3);
                                                break;
                                            case 2:
                                                //Filtrar clientes
                                                option = administradorMenuFiltrarClientes();
                                                String dataFiltro;
                                                switch(option){
                                                    case 1:
                                                        option = administradorSeleccionCriterioFiltro();
                                                        switch(option){
                                                            case 1:
                                                                //Menor
                                                                administradorFiltrarClientes(clientes, "Menor", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                            case 2:
                                                                //Igual
                                                                administradorFiltrarClientes(clientes, "Igual", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                            case 3:
                                                                //Mayor
                                                                administradorFiltrarClientes(clientes, "Mayor", "cantLibrosPrestados", administradorIngresoDataFiltro("cantLibrosPrestados"));
                                                                break;
                                                        }
                                                        break;
                                                    case 2:
                                                        administradorFiltrarClientes(clientes, null, "estadoSancion", administradorIngresoDataFiltro("estadoSancion"));
                                                        break;
                                                    case 0:
                                                        //
                                                        break;
                                                }
                                                break;
                                            case 0:
                                                band2 = false;
                                        }
                                    }while(band2);
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                            }
                        }while(band1);
                    }else{
                        //PARA EL RECEPCIONISTA
                        band1 = true;
                        do{
                            option = recepcionistaMainMenu(datosInicioSesion.get(1));
                            switch(option){
                                case 1:
                                    //Gestión de clientes
                                    clientesVistaPrevia(clientes);
                                    option = recepcionistaGestionClientes();
                                    switch(option){
                                        case 1:
                                            //Mostrar historial de un cliente
                                            int idActualCliente;
                                            idActualCliente = busquedaIDCliente(clientes);
                                            break;
                                        case 2:
                                            //Realizar préstamo de libros (FUNCION PRINCIPAL)
                                            break;
                                        case 0:
                                            break;
                                    }
                                    break;
                                case 2:
                                    //Consulta de libros
                                    librosVistaPrevia(libros);
                                    System.out.println("1.- Buscar libro");
                                    System.out.println("2.- Filtrar libros");
                                    System.out.println("0.- Volver");
                                    break;
                                case 3:
                                    //Consulta de historial de rentas generadas
                                    boletasVistaPrevia(boletas, clientes, libros, usuarios, datosInicioSesion.get(0));
                                    System.out.println("1.- Ver detalles de rentas por ID");
                                    System.out.println("0.- Volver");
                                    break;
                                case 4:
                                    //Consulta de horario personal
                                    recepcionistaHorarioPersonal(usuarios, datosInicioSesion.get(1));//PENDIENTE: REVISAR METODO
                                    break;
                                case 0:
                                    cierreSesion();
                                    band1 = false;
                                    break;
                            }
                        }while(band1);
                    }
                    break;
                case 0:
                    inicioSesionValido = false;
                    break;
            }
        }while(inicioSesionValido);
        
        System.out.println("ALL WORKING");
    }
}

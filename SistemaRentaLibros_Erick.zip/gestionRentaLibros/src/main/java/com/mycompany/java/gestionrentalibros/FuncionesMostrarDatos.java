package com.mycompany.java.gestionrentalibros;

import Classes.Boleta;
import Classes.Cliente;
import Classes.Libro;
import Classes.Usuario;
import static com.mycompany.java.gestionrentalibros.MainFunciones.read;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.IDActualUser;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.datosInicioSesion;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.formato;
import java.util.List;

public class FuncionesMostrarDatos {
    //FUNCIONES DE VISUALIZACION PREVIA DE DATOS
    static void recepcionistasVistaPrevia(List<Usuario> usuarios){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE RECEPCIONISTAS: ");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("ID\t\t\tNombre\t\t\tInicio Turno(h)\t\t\tFin Turno(h)");
        System.out.println("--------------------------------------------------------------------------------");
        for(Usuario user : usuarios){
            if(user.getPosicion().equals("Recepcionista")){
                System.out.println(user.getID() + "\t\t\t" + user.getNombre() + "\t\t\t" + user.getHoraInicio() + "\t\t\t" + user.getHoraFin());
            }
        }
    }
    
    static void clientesVistaPrevia(List<Cliente> clientes){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE CLIENTES: ");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("ID\t\tNombre\t\tN° Libros Prestados\tEstado de sanción");
        System.out.println("----------------------------------------------------------------------");
        for(Cliente client : clientes){
            System.out.println(client.getID() + "\t\t" + client.getNombre() + "\t\t" + client.getCantLibrosPrestados() + "\t\t\t" + client.getEstadoSancion());
        }
    }
    
    static void librosVistaPrevia(List<Libro> libros){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE LIBROS: ");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        System.out.println("ID\t\tTítulo\t\tEditorial\t\tGénero\t\tN° Páginas\tUnid. Disponibles");
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        for(Libro book : libros){
            System.out.println(book.getID() + "\t\t" + book.getTitulo() + "\t\t" + book.getEditorial() + "\t\t" + book.getGenero() + "\t\t" + book.getnPaginas() + "\t\t" + book.getUnidDisponibles());
        }
    }
    
    static void boletasVistaPrevia(List<Boleta> boletas, List<Cliente> clientes, List<Libro> libros, List<Usuario> usuarios, String tipoUsuario){
        System.out.println("----------------------------------------");
        System.out.println("LISTA DE BOLETAS GENERADAS");
        System.out.println("----------------------------------------");
        if(tipoUsuario.equals("Administrador")){
            for(Boleta ticket : boletas){
                System.out.println("Boleta N° " + ticket.getIDBoleta());
                for(Cliente client : clientes){
                    if(client.getID() == ticket.getIDCliente()){
                        System.out.println("Cliente: " + client.getNombre());
                        break;
                    }
                }
                for(Libro book : libros){
                    if(book.getID() == ticket.getIDLibro()){
                        System.out.println("Libro: " + book.getTitulo());
                        break;
                    }
                }
                System.out.println("Fecha de préstamo: " + formato.format(ticket.getFechaPrestamo()));
                System.out.println("Fecha estimada para la devolución: " + formato.format(ticket.getFechaDevolucion()));
                System.out.println("----------------------------------------");
            }
        }else{
            IDActualUser = 0;
            for(Usuario user : usuarios){
                if(user.getNombre().equals(datosInicioSesion.get(1))) IDActualUser = user.getID();
            }
            for(Boleta ticket : boletas){
                if(ticket.getIDRecepcionista() == IDActualUser){
                    System.out.println("Boleta N° " + ticket.getIDBoleta());
                    for(Cliente client : clientes){
                        if(client.getID() == ticket.getIDCliente()){
                            System.out.println("Cliente: " + client.getNombre());
                            break;
                        }
                    }
                    for(Libro book : libros){
                        if(book.getID() == ticket.getIDLibro()){
                            System.out.println("Libro: " + book.getTitulo());
                            break;
                        }
                    }
                    System.out.println("Fecha de préstamo: " + formato.format(ticket.getFechaPrestamo()));
                    System.out.println("Fecha estimada para la devolución: " + formato.format(ticket.getFechaDevolucion()));
                    System.out.println("----------------------------------------");
                }
            }
        }
    }
    
    //FUNCIONES DE VISUALIZACIÓN DETALLADA DE DATOS
    static void recepcionistaHorarioPersonal(List <Usuario> usuarios, String usuario){
        System.out.println("----------------------------------------");
        System.out.println("HORARIO PERSONAL: ");
        for(Usuario user : usuarios){
            if(user.getNombre().equals(usuario)){
                user.mostrarHorarioFormato(user.getHoraInicio(), user.getHoraFin());
                break;
            }
        }
        System.out.print("Presione ENTER para continuar ");
        read.nextLine();//PARCHE
        read.nextLine();
    }
    
    static void recepcionistaVistaDetallada(List<Usuario> usuarios, int ID){
        for(Usuario user : usuarios){
            user.mostrarUsuario();
        }
    }
}

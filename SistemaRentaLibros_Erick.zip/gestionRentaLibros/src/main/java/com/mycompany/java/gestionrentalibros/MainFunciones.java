package com.mycompany.java.gestionrentalibros;

import Classes.Boleta;
import Classes.Canasta;
import Classes.Cliente;
import Classes.Libro;
import Classes.Usuario;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.*;
import java.text.ParseException; //En caso el dato sea inválido
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainFunciones {
    
    static Scanner read = new Scanner(System.in);
    
    //MENU PRINCIPAL
    static int mainMenu(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO AL SISTEMA DE GESTIÓN DE RENTA DE LIBROS");
        System.out.println("1.- Iniciar sesión");
        System.out.println("0.- Salir");
        return seleccionOpcion(0, 1);
    }
    
    //FUNCION DE INICIO DE SESIÓN
    static List<String> inicioSesion(List<Usuario> usuarios){
        boolean parcheError = true;
        System.out.println("----------------------------------------");
        System.out.println("GESTIÓN DE RENTA DE LIBROS");
        System.out.println("----------------------------------------");
        List<String> datos = new ArrayList<>(3);
        String indDato;
        System.out.println("INICIO DE SESIÓN");
        System.out.println("Ingrese su posición, usuario y contraseña");
        if(parcheError) read.nextLine(); //Parche de un error de lectura
        do{
            System.out.print("Posición (Administrador/Recepcionista): ");
            indDato = read.nextLine();
            if(indDato.equals("Administrador") || indDato.equals("Recepcionista")){
                datos.add(indDato);
                System.out.print("Usuario: ");
                indDato = read.nextLine();
                datos.add(indDato);
                System.out.print("Contraseña: ");
                indDato = read.nextLine();
                datos.add(indDato);

                //Verificando inicio de sesión
                inicioSesionValido = false;
                if("Administrador".equals(datos.get(0))){
                    //Verificación con los objetos de la clase Usuario
                    for(Usuario user : usuarios){
                        if(user.getPosicion().equals("Administrador") && (user.getNombre().equals(datos.get(1)) && user.getContrasena().equals(datos.get(2)))) inicioSesionValido = true;
                    }
                }
                if("Recepcionista".equals(datos.get(0))){
                    //Verificación con los objetos de la clase Usuario
                    for(Usuario user : usuarios){
                        if(user.getPosicion().equals("Recepcionista") && (user.getNombre().equals(datos.get(1)) && user.getContrasena().equals(datos.get(2)))) inicioSesionValido = true;
                    }
                }
                if(!inicioSesionValido){
                    System.out.println("Inicio de sesion invalido, intente nuevamente...");
                    parcheError = false;
                    datos.clear();
                }
            }else{
                System.out.println("Posición inválida, intente nuevamente...");
            }
        }while(!inicioSesionValido);
        System.out.println("Inicio de sesión realizado con éxito");
        return datos;
    }
    
    //FUNCION DE CIERRE DE SESION
    static void cierreSesion(){
        System.out.println("----------------------------------------");
        System.out.println("SESION FINALIZADA");
        System.out.println("----------------------------------------");
    }
    
    //Funciones adicionales
    static int seleccionOpcion(int limiteInferior, int limiteSuperior){
        int opcion;
        do{
            System.out.print("Seleccione una opción: ");
            opcion = read.nextInt();
            if(opcion<limiteInferior || opcion >limiteSuperior) System.out.println("Opción inválida, intente nuevamente...");
        }while(opcion<limiteInferior || opcion >limiteSuperior);
        return opcion;
    }
    
    static int busquedaIDCliente(List<Cliente> clientes){
        int clienteID;
        boolean validarID = false;
        System.out.println("----------------------------------------");
        do{
            System.out.print("Ingrese el ID del cliente: ");
            clienteID = read.nextInt();
            for(Cliente client : clientes){
                if(client.getID() == clienteID) validarID = true;
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return clienteID;
    }
}

package com.mycompany.java.gestionrentalibros;

import Classes.Cliente;
import Classes.Usuario;
import static com.mycompany.java.gestionrentalibros.MainFunciones.read;
import static com.mycompany.java.gestionrentalibros.MainFunciones.seleccionOpcion;
import java.util.List;

public class FuncionesAdministrador {
    //FUNCIONES DE ELECCION DE OPCIONES DE MENUS o DE INGRESO DE DATOS
    //ADMINISTRADOR
    static int administradorMainMenu(String nombre){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO " + nombre.toUpperCase());
        System.out.println("1.- Gestión de recepcionistas");
        System.out.println("2.- Consulta de clientes");
        System.out.println("0.- Cerrar sesión");
        return seleccionOpcion(0, 2);
    }
    
    static int administradorGestionRecepcionistas(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Ver detalles de un recepcionista"); //Dentro estaría "modificar datos del recepcionista"
        System.out.println("2.- Añadir recepcionista");
        System.out.println("3.- Eliminar recepcionista");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 3);
    }
    
    static int administradorSeleccionRecepcionista(List<Usuario> usuarios){
        int recepcionistaID;
        boolean validarID = false;
        System.out.println("----------------------------------------");
        do{
            System.out.print("Ingrese el ID del recepcionista: ");
            recepcionistaID = read.nextInt();
            for(Usuario user : usuarios){
                if(user.getID() == recepcionistaID) validarID = true;
            }
            if(!validarID){
                System.out.println("ID no encontrada, intente nuevamente...");
            }
        }while(!validarID);
        return recepcionistaID;
    }
    
    static int administradorVerDetallesRecepcionista(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Modificar nombre");
        System.out.println("2.- Modificar DNI");
        System.out.println("3.- Modificar posicion"); //En caso de ascenso
        System.out.println("4.- Modificar contraseña");
        System.out.println("5.- Modificar horario");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 5);
    }
    
    static void administradorModificarNombreRecepcionista(int IDRecepcionista, List<Usuario> usuarios){
        String newNombre;
        System.out.println("----------------------------------------");
        for(Usuario user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Nombre actual: " + user.getNombre());
                System.out.print("Ingrese el nuevo nombre: ");
                read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
                newNombre = read.nextLine();
                if(administradorConfirmarModificacion()){
                    user.setNombre(newNombre); //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarDNIRecepcionista(int IDRecepcionista, List<Usuario> usuarios){
        int newDNI;
        System.out.println("----------------------------------------");
        for(Usuario user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("DNI actual: " + user.getDNI());
                System.out.print("Ingrese el nuevo DNI: ");
                read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
                newDNI = read.nextInt();
                if(administradorConfirmarModificacion()){
                    user.setDNI(newDNI); //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarPosicionRecepcionista(int IDRecepcionista, List<Usuario> usuarios){
        int opcion;
        System.out.println("----------------------------------------");
        for(Usuario user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Posicion actual: " + user.getPosicion());
                System.out.println("¿Desea cambiar su posición a administrador?");
                System.out.println("1.- SI");
                System.out.println("0.- NO");
                opcion = seleccionOpcion(0,1);
                if(opcion == 1){
                    user.setPosicion("Administrador");
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarContrasenaRecepcionista(int IDRecepcionista, List<Usuario> usuarios){
        String newContrasena;
        System.out.println("----------------------------------------");
        for(Usuario user: usuarios){
            if(user.getID() == IDRecepcionista){
                System.out.println("Contraseña actual: " + user.getNombre());
                System.out.print("Ingrese la nueva contraseña: ");
                read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
                newContrasena = read.nextLine();
                if(administradorConfirmarModificacion()){
                    user.setContrasena(newContrasena);
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorModificarHorarioRecepcionista(int IDRecepcionista, List<Usuario> usuarios){
        int newHoraInicio, newHoraFin;
        System.out.println("----------------------------------------");
        for(Usuario user: usuarios){
            if(user.getID() == IDRecepcionista){
                read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
                System.out.println("Horario actual: " + user.mostrarHorarioFormato(user.getHoraInicio(), user.getHoraFin()));
                newHoraInicio = seleccionOpcion(1,24);
                newHoraFin = seleccionOpcion(1,24);
                if(administradorConfirmarModificacion()){
                    user.setHoraInicio(newHoraInicio);
                    user.setHoraFin(newHoraFin);
                    //En la función correspondiente, añadir que el valor tambien se modifique en la base de datos
                    System.out.println("Los cambios se han guardado correctamente");
                }else{
                    System.out.println("Los cambios no han sido guardados");
                }
            }
        }
    }
    
    static void administradorAnadirRecepcionista(List<Usuario> usuarios){
        String newNombre, newContrasena;
        int newID = 0, newDNI, newHoraInicio, newHoraFin;
        //Ingreso de datos
        System.out.println("----------------------------------------");
        System.out.println("AÑADIR NUEVO RECEPCIONISTA");
        System.out.print("Ingrese el nombre: ");
        read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
        newNombre = read.nextLine();
        System.out.print("Ingrese el DNI: ");
        newDNI = read.nextInt();
        System.out.print("Ingrese la contraseña: ");
        read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
        newContrasena = read.nextLine();
        System.out.print("Ingrese la hora de inicio del turno: ");
        newHoraInicio = read.nextInt();
        System.out.print("Ingrese la hora de final del turno: ");
        newHoraFin = read.nextInt();
        if(administradorConfirmarModificacion()){
            //Generacion aleatoria de ID
            boolean unique;
            do{
                unique = true;
                newID = 100 + (int)(Math.random()*900);
                for(Usuario user : usuarios){
                    if(user.getID() == newID){
                        unique = false;
                    }
                }
            }while(!unique);
            usuarios.get(usuarios.size()-1).anadirUsuario(usuarios, newID, newNombre, newDNI, "Recepcionista", newContrasena, newHoraInicio, newHoraFin);
            System.out.println("Los cambios se han guardado correctamente");
        }else{
            System.out.println("Los cambios no han sido guardados");
        }
    }
    
    static List<Usuario> administradorEliminarRecepcionista(List<Usuario> usuarios){
        int selectID;
        boolean ver = false;
        System.out.println("----------------------------------------");
        System.out.println("ELIMINAR UN RECEPCIONISTA");
        do{
            System.out.print("Ingrese la ID del recepcionista a eliminar: ");
            selectID = read.nextInt();
            for(Usuario user : usuarios){
                if(user.getPosicion().equals("Recepcionista") && user.getID() == selectID){
                    ver = true;
                    if(administradorConfirmarModificacion()){
                        user.eliminarUsuario(usuarios, user);
                        System.out.println("El usuario se ha eliminado correctamente");
                        break;
                    }else{
                        System.out.println("El usuario no ha sido eliminado");
                    }
                    break;
                }
            }
            if(!ver) System.out.println("ID no encontrada, intente nuevamente...");
        }while(!ver);
        return usuarios;
    }
    
    static boolean administradorConfirmarModificacion(){
        boolean confirmacion;
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("¿Desea guardar los cambios realizados?");
        System.out.println("1.- SI");
        System.out.println("0.- NO");
        opcion = seleccionOpcion(0,1);
        confirmacion = (opcion == 1);
        return confirmacion;
    }
    
    static int administradorGestionClientes(){
        System.out.println("----------------------------------------");
        System.out.println("1.- Buscar cliente");//Por nombre, por DNI, por telefono
        System.out.println("2.- Filtrar clientes"); //Por estado sanción, cantLibrosPrestados, 
        System.out.println("0.- Volver");
        return seleccionOpcion(0,2);
    }
    
    static int administradorBuscarClientes(List<Cliente> clientes){
        String clientData;
        System.out.print("Ingrese un dato del cliente (Nombre/DNI/Teléfono): ");
        read.nextLine();//PARCHE DE ERROR DE LECTURA
        clientData = read.nextLine();
        System.out.println("----------------------------------------");
        System.out.println("CLIENTES ENCONTRADOS: ");
        for(Cliente client : clientes){
            if(client.buscarCliente(clientData, client)){
                client.mostrarCliente();
            }
        }
        System.out.println("1.- Realizar otra búsqueda");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,1);
    }
    
    static int administradorMenuFiltrarClientes(){
        System.out.println("1.- Filtrar por cantidad de libros prestados");
        System.out.println("2.- Filtrar por estado de sanción");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,2);
    }
    
    static int administradorSeleccionCriterioFiltro(){
        System.out.println("----------------------------------------");
        System.out.println("1.- Menor a una cantidad");
        System.out.println("2.- Igual a una cantidad");
        System.out.println("3.- Mayor a una cantidad");
        return seleccionOpcion(1,3);
    }
    
    static String administradorIngresoDataFiltro(String tipoData){
        if(tipoData.equals("cantLibrosPrestados")){
            System.out.print("Ingrese la cantidad: ");
        }else{
            System.out.print("Ingrese el estado de sanción (ACTIVO/INACTIVO): ");
        }
        read.nextLine(); //PARCHE
        return read.nextLine();
    }
    
    static void administradorFiltrarClientes(List<Cliente> clientes, String tipoFiltro, String tipoData, String dataFiltro){
        boolean ver = false;
        for(Cliente client : clientes){
            if(client.filtrarCliente(tipoFiltro, tipoData, dataFiltro)){
                ver = true;
                client.mostrarCliente(); //Posible cambio a vista previa
            }
        }
        if(!ver) System.out.println("No se encontraron datos con las indicaciones ingresadas");
        System.out.print("Presione ENTER para continuar ");//Revisar esto
        read.nextLine();
    }
}

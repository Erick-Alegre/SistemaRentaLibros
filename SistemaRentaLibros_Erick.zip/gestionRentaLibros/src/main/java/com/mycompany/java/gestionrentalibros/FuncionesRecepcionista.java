package com.mycompany.java.gestionrentalibros;

import Classes.Boleta;
import Classes.Canasta;
import static com.mycompany.java.gestionrentalibros.GestionRentaLibros.*;
import static com.mycompany.java.gestionrentalibros.FuncionesMostrarDatos.*;
import static com.mycompany.java.gestionrentalibros.MainFunciones.*;
import Classes.Cliente;
import Classes.Libro;
import Classes.Usuario;
import Classes.historialCliente;
import static com.mycompany.java.gestionrentalibros.MainFunciones.read;
import static com.mycompany.java.gestionrentalibros.MainFunciones.seleccionOpcion;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FuncionesRecepcionista {
    //FUNCIONES DE ELECCION DE OPCIONES DE MENUS o DE INGRESO DE DATOS
    //RECEPCIONISTA
    static int recepcionistaMainMenu(String nombre){
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO " + nombre.toUpperCase());
        System.out.println("1.- Gestión de clientes");
        System.out.println("2.- Consulta de libros");
        System.out.println("3.- Consulta de historial de boletas generadas");
        System.out.println("4.- Consulta de horario personal");
        System.out.println("0.- Cerrar sesión");
        return seleccionOpcion(0, 4);
    }
    
    static int recepcionistaGestionClientes(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Ver detalles de un cliente");
        System.out.println("2.- Añadir cliente");
        System.out.println("3.- Realizar préstamo de libros");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 3);
    }
    
    static int recepcionistaVerDetallesCliente(List<Cliente> clientes){
        System.out.println("1.- Mostrar historial de préstamos del cliente");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,1);
    }
    
    static void recepcionistaMostrarHistorialCliente(List<Cliente> clientes, List<historialCliente> historialClientes, List<Libro> libros, int idActualCliente){
        System.out.println("----------------------------------------");
        System.out.print("HISTORIAL DEL CLIENTE ");
        for(Cliente client : clientes){
            if(client.getID() == idActualCliente){
                System.out.print(client.getNombre());
                break;
            }
        }
        System.out.println(": ");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("IDLibro\t\tLibro\t\tFecha de Préstamo\tFecha de devolución"); //POSIBLEMENTE AÑADIR PUNTUALIDAD EN LA DEVOLUCION
        System.out.println("----------------------------------------------------------------------");
        for(historialCliente clientRecord : historialClientes){
            if(clientRecord.getIDCliente() == idActualCliente){
                System.out.print(clientRecord.getIDLibro() + "\t\t");
                for(Libro book : libros){
                    if(book.getID() == clientRecord.getIDLibro()){
                        System.out.print(book.getTitulo() + "\t\t");
                    }
                }
                System.out.print(formato.format(clientRecord.getFechaPrestamo()) + "\t\t");
                try {
                    if(clientRecord.getFechaDevolucion().equals(formato.parse("00-00-0000"))){
                        System.out.println("PENDIENTE");
                    }else{
                        System.out.println(formato.format(clientRecord.getFechaDevolucion()));
                    }
                } catch (ParseException ex) {
                    Logger.getLogger(FuncionesRecepcionista.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        System.out.print("Presione ENTER para continuar ");//Revisar esto
        read.nextLine();//PARCHE
        read.nextLine();
    }
    
    static void recepcionistaAnadirCliente(List<Cliente> clientes, List<Canasta> canastas){
        String newNombre;
        int newID = 0, newDNI, newTelefono;
        //Ingreso de datos
        System.out.println("----------------------------------------");
        System.out.println("AÑADIR NUEVO CLIENTE");
        System.out.print("Ingrese el nombre: ");
        read.nextLine(); //PARCHE DE ERROR DE SALTO DE LECTURA
        newNombre = read.nextLine();
        System.out.print("Ingrese el DNI: ");
        newDNI = read.nextInt();
        System.out.print("Ingrese el teléfono del cliente: ");
        newTelefono = read.nextInt();
        if(ConfirmarModificacion()){
            //Generacion aleatoria de ID del cliente
            boolean unique;
            do{
                unique = true;
                newID = 1000 + (int)(Math.random()*9000);
                for(Cliente client : clientes){
                    if(client.getID() == newID){
                        unique = false;
                    }
                }
            }while(!unique);
            clientes.get(clientes.size()-1).anadirCliente(clientes, newID, newNombre, newDNI, newTelefono);
            canastas.get(canastas.size()-1).anadirCanasta(canastas, newID);
            System.out.println("Los cambios se han guardado correctamente");
        }else{
            System.out.println("Los cambios no han sido guardados");
        }
    }
    
    static boolean recepcionistaVerificarClientePrestamo(List<Cliente> clientes, List<Canasta> canastas, String nombreCliente){
        boolean ver1 = false, ver2 = true;
        for(Cliente client : clientes){
            if(client.getNombre().equals(nombreCliente)){
                ver1 = true;
                for(Canasta shopCart: canastas){
                    if(shopCart.getIDCliente() == client.getID() && shopCart.getIDLibrosEnCanasta().size()==6){
                        ver2 = false;
                        System.out.println("La canasta del cliente está llena");
                    }
                }
                if(client.getEstadoSancion()){
                    ver2 = false;
                    System.out.println("El estado de sanción del cliente está activo");
                }
                break;
            }
        }
        if(!ver1) System.out.println("El cliente no se encuentra registrado");
        return ver1 && ver2;
    }
    
    static boolean recepcionistaVerificarLibroPrestamo(List<Libro> libros, String tituloLibro){
        boolean ver1 = false, ver2 = true;
        for(Libro book: libros){
            if(book.getTitulo().equals(tituloLibro)){
                ver1 = true;
                if(book.getUnidDisponibles()==0){
                    ver2 = false;
                    System.out.println("No hay unidades disponibles del libro");
                }
            }
        }
        if(!ver1) System.out.println("El libro no fue encontrado");
        return ver1 && ver2;
    }
    
    static void recepcionistaAnadirBoleta(List<Boleta> boletas, List<Libro> libros, List<Cliente> clientes, List<Usuario> usuarios, String nombreRecepcionista, String nombreCliente, String tituloLibro){
        //Generacion aleatoria de ID de boleta
        int newIDBoleta, newIDRecepcionista = 0, newIDCliente = 0, newIDLibro = 0;
        String newFechaPrestamo = formato.format("00-00-0000");
        System.out.println("AÑADIR BOLETA: FECHAS");
        boolean unique;
        do{
            unique = true;
            newIDBoleta = 1000 + (int)(Math.random()*9000);
            for(Boleta ticket : boletas){
                if(ticket.getIDBoleta() == newIDBoleta){
                    unique = false;
                }
            }
        }while(!unique);
        System.out.println("AÑADIR BOLETA: ALEATORIO");
        for(Usuario user : usuarios){
            if(user.getNombre().equals(nombreRecepcionista)){
                newIDRecepcionista = user.getID();
            }
        }
        for(Cliente client : clientes){
            if(client.getNombre().equals(nombreCliente)){
                newIDCliente = client.getID();
            }
        }
        for(Libro book : libros){
            if(book.getTitulo().equals(tituloLibro)){
                newIDLibro = book.getID();
            }
        }
        System.out.println("AÑADIR BOLETA: BUSQUEDA DE DATOS");
        //Generar nueva boleta
        try {
            boletas.get(boletas.size()-1).anadirBoleta(boletas, newIDBoleta, newIDRecepcionista, newIDCliente, newIDLibro, formato.parse(newFechaPrestamo), formato.parse(newFechaPrestamo));
        } catch (ParseException ex) {
            Logger.getLogger(FuncionesRecepcionista.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("SALE DE LA FUNCION DE AÑADIR BOLETA");
        
    }
    
    static int recepcionistaConsultaLibros(){
        System.out.println("1.- Buscar libro");
        System.out.println("2.- Filtrar libros");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,2);
    }
    
    static void recepcionistaAnadirLibroCanasta(List<Canasta> canastas, List<Usuario> usuarios, List<Libro> libros, List<Cliente> clientes, String nombreRecepcionista, String nombreCliente, String tituloLibro){
        System.out.println("INGRESA A FUNCION DE AÑADIR LIBRO A CANASTA");
        int IDRecepcionista = 0, IDCliente = 0;
        for(Usuario user : usuarios){
            if(user.getNombre().equals(nombreRecepcionista)){
                IDRecepcionista = user.getID();
            }
        }
        for(Cliente client : clientes){
            if(client.getNombre().equals(nombreCliente)){
                IDCliente = client.getID();
            }
        }
        for(Canasta shopCart : canastas){
            if(shopCart.getIDCliente() == IDCliente){
                for(Libro book : libros){
                    if(book.getTitulo().equals(tituloLibro)){
                        shopCart.getIDLibrosEnCanasta().add(book.getID());
                    }
                }
            }
        }
        System.out.println("SALE DE LA FUNCION DE AÑADIR LIBRO A CANASTA");
    }
    
    static void recepcionistaModifacarUnidDisponiblesLibro(List<Libro> libros, String tituloLibro){
        for(Libro book : libros){
            if(book.getTitulo().equals(tituloLibro)){
                book.setUnidDisponibles(book.getUnidDisponibles()-1);
            }
        }
    }
    
    static int recepcionistaBuscarLibros(List<Cliente> clientes, List<Libro> libros){
        String bookData;
        String searchTitle, searchEditorial, searchGenero;
        String searchFechaPublicacion;
        System.out.println("Ingrese la información del libro (Caso contrario ingrese '0')");
        System.out.print("Ingrese el nombre del libro: ");
        read.nextLine(); //PARCHE
        searchTitle = read.nextLine();
        System.out.print("Ingrese la fecha de publicación (DD-MM-YYYY): ");
        searchFechaPublicacion = read.nextLine();
        System.out.print("Ingrese la editorial: ");   
        searchEditorial = read.nextLine();
        System.out.println("Lista de genéros literarios");
        System.out.println("M.- Misterio");
        System.out.println("F.- Fantasía");
        System.out.println("R.- Romance");
        System.out.println("A.- Aventura");
        System.out.println("CF.- Ciencia Ficción");
        System.out.println("T.- Terror");
        System.out.print("Seleccione la abreviatura de un género literario: ");
        searchGenero = read.nextLine();
        for(Libro book : libros){
            boolean foundBook = true;
            if(!searchTitle.equals("0") && !book.getTitulo().equals(searchTitle)) foundBook = false;
            if(!searchEditorial.equals("0") && !book.getEditorial().equals(searchEditorial)) foundBook = false;
            try {
                if(!searchFechaPublicacion.equals("0") && !book.getFechaPublicacion().equals(formato.parse(searchFechaPublicacion))) foundBook = false;
            } catch (ParseException ex) {
                Logger.getLogger(FuncionesRecepcionista.class.getName()).log(Level.SEVERE, null, ex);
            }
            if(!searchGenero.equals("0") && !book.getGenero().equals(searchGenero)) foundBook = false;
            if(foundBook){
                libroVistaDetallada(libros, book.getID());
            }
        }
        System.out.println("1.- Realizar otra búsqueda");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,1);
    }
    
    static int recepcionistaMenuFiltrarLibros(){ //PublicationDate,Editorial,Gender,NPages
        System.out.println("1.- Filtrar por fecha de publicación");
        System.out.println("2.- Filtrar por editorial");
        System.out.println("3.- Filtrar por género");
        System.out.println("4.- Filtrar por número de páginas");
        System.out.println("0.- Volver");
        return seleccionOpcion(0,4);
    }
    
    static int recepcionistaSeleccionCriterioFiltro(String dataFiltro){
        if(dataFiltro.equals("fechaPublicacion")){
            System.out.println("----------------------------------------");
            System.out.println("1.- Anterior a una fecha");
            System.out.println("2.- Igual a una fecha");
            System.out.println("3.- Posterior a una fecha");
        }else{
            System.out.println("----------------------------------------");
            System.out.println("1.- Menor a una cantidad");
            System.out.println("2.- Igual a una cantidad");
            System.out.println("3.- Mayor a una cantidad");
        }
        return seleccionOpcion(1,3);
    }
    
    static String recepcionistaIngresoDataFiltro(String tipoData){
        if(tipoData.equals("fechaPublicacion")){
            System.out.print("Ingrese la fecha (DD-MM-YYYY): ");
        }
        if(tipoData.equals("editorial")){
            System.out.print("Ingrese la editorial: ");
        }
        if(tipoData.equals("genero")){
            System.out.println("Lista de genéros literarios");
            System.out.println("M.- Misterio");
            System.out.println("F.- Fantasía");
            System.out.println("R.- Romance");
            System.out.println("A.- Aventura");
            System.out.println("CF.- Ciencia Ficción");
            System.out.println("T.- Terror");
            System.out.print("Ingrese la abreviatura de un género literario: ");
        }
        if(tipoData.equals("nPaginas")){
            System.out.print("Ingrese un número de páginas: ");
        }
        read.nextLine(); //PARCHE
        return read.nextLine();
    }
    
    static void recepcionistaFiltrarLibros(List<Libro> libros, String tipoFiltro, String tipoData, String dataFiltro){
        boolean ver = false;
        for(Libro book : libros){
            if(book.filtrarLibro(tipoFiltro, tipoData, dataFiltro)){
                ver = true;
                book.mostrarLibro(); //Posible cambio a vista previa
            }
        }
        if(!ver) System.out.println("No se encontraron datos con las indicaciones ingresadas");
        System.out.print("Presione ENTER para continuar ");//Revisar esto
        read.nextLine();
    }
    
    
}

package com.mycompany.java.gestionrentalibros;

import Classes.Canasta;
import Classes.Cliente;
import Classes.Libro;
import static com.mycompany.java.gestionrentalibros.MainFunciones.read;
import static com.mycompany.java.gestionrentalibros.MainFunciones.seleccionOpcion;
import java.text.ParseException;
import java.util.List;

public class FuncionesRecepcionista {
    //FUNCIONES DE ELECCION DE OPCIONES DE MENUS o DE INGRESO DE DATOS
    //RECEPCIONISTA
    static int recepcionistaMainMenu(String nombre){
        System.out.println("----------------------------------------");
        System.out.println("BIENVENIDO " + nombre.toUpperCase());
        System.out.println("1.- Gestión de clientes");
        System.out.println("2.- Consulta de libros");
        System.out.println("3.- Consulta de historial de rentas generadas");
        System.out.println("4.- Consulta de horario personal");
        System.out.println("0.- Cerrar sesión");
        return seleccionOpcion(0, 4);
    }
    
    static int recepcionistaGestionClientes(){
        int opcion;
        System.out.println("----------------------------------------");
        System.out.println("1.- Mostrar historial de un cliente");
        System.out.println("2.- Realizar préstamo de libros");
        System.out.println("0.- Volver");
        return seleccionOpcion(0, 2);
    }
    
    static void recepcionistaMostrarHistorialCliente(List<Cliente> clientes, List<Canasta> canastas, List<Libro> libros, int idActualCliente) throws ParseException{
        System.out.println("----------------------------------------");
        System.out.print("HISTORIAL DEL CLIENTE ");
        for(Cliente client : clientes){
            if(client.getID() == idActualCliente){
                System.out.print(client.getNombre());
                break;
            }
        }
        System.out.println(": ");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("IDLibro\t\tLibro\t\tFecha de Préstamo\tFecha de devolución"); //POSIBLEMENTE AÑADIR PUNTUALIDAD EN LA DEVOLUCION
        System.out.println("----------------------------------------------------------------------");
        /*for(Canasta shopCart : canastas){
            if(shopCart.getIDCliente() == idActualCliente){
                System.out.print(shopCart.getIDLibro() + "\t\t");
                for(Libro book : libros){
                    if(book.getID() == shopCart.getIDLibro()){
                        System.out.print(book.getTitulo() + "\t\t");
                    }
                }
                System.out.println(formato.format(shopCart.getFechaPrestamo()) + "\t\t");
                if(shopCart.getFechaDevolucion() == formato.parse("00-00-0000")){
                    System.out.println("PENDIENTE");
                }else{
                    System.out.println(formato.format(shopCart.getFechaDevolucion()));
                }
            }
        }*/
        System.out.print("Presione ENTER para continuar ");//Revisar esto
        read.nextLine();//PARCHE
        read.nextLine();
    }
}
